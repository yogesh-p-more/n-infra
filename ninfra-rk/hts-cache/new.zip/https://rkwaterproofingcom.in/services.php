<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>R.K. Waterproofing and Company</title>
<link rel="icon" type="image/png" sizes="32x32" href="assets/images/favicons/favicon-32x32.png" />
<meta name="description" content="R.K. Waterproofing and Company" />
<link rel="preconnect" href="https://fonts.googleapis.com/">
<link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
<link
    href="https://fonts.googleapis.com/css2?family=Barlow:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&amp;display=swap"
    rel="stylesheet">
<link
    href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&amp;display=swap"
    rel="stylesheet">
<link
    href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&amp;display=swap"
    rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Yantramanav:wght@100;300;400;500;700;900&amp;display=swap"
    rel="stylesheet">

<link rel="stylesheet" href="assets/vendors/bootstrap/css/bootstrap.min.css" />
<link rel="stylesheet" href="assets/vendors/animate/animate.min.css" />
<link rel="stylesheet" href="assets/vendors/animate/custom-animate.css" />
<link rel="stylesheet" href="assets/vendors/fontawesome/css/all.min.css" />
<link rel="stylesheet" href="assets/vendors/jarallax/jarallax.css" />
<link rel="stylesheet" href="assets/vendors/jquery-magnific-popup/jquery.magnific-popup.css" />
<link rel="stylesheet" href="assets/vendors/nouislider/nouislider.min.css" />
<link rel="stylesheet" href="assets/vendors/nouislider/nouislider.pips.css" />
<link rel="stylesheet" href="assets/vendors/odometer/odometer.min.css" />
<link rel="stylesheet" href="assets/vendors/swiper/swiper.min.css" />
<link rel="stylesheet" href="assets/vendors/endreox-icons/style.css">
<link rel="stylesheet" href="assets/vendors/tiny-slider/tiny-slider.min.css" />
<link rel="stylesheet" href="assets/vendors/reey-font/stylesheet.css" />
<link rel="stylesheet" href="assets/vendors/owl-carousel/owl.carousel.min.css" />
<link rel="stylesheet" href="assets/vendors/owl-carousel/owl.theme.default.min.css" />
<link rel="stylesheet" href="assets/vendors/bxslider/jquery.bxslider.css" />
<link rel="stylesheet" href="assets/vendors/bootstrap-select/css/bootstrap-select.min.css" />
<link rel="stylesheet" href="assets/vendors/vegas/vegas.min.css" />
<link rel="stylesheet" href="assets/vendors/jquery-ui/jquery-ui.css" />
<link rel="stylesheet" href="assets/vendors/timepicker/timePicker.css" />
<link rel="stylesheet" href="assets/vendors/free-hand-font/stylesheet.css" />

<!-- template styles -->
<link rel="stylesheet" href="assets/css/endreox.css" />
<link rel="stylesheet" href="assets/css/endreox-responsive.css" />
</head>

<body class="custom-cursor">

    <div class="custom-cursor__cursor"></div>
    <div class="custom-cursor__cursor-two"></div>

<div class="page-wrapper">

<header class="main-header-three">
    <div class="main-header-three__top">
        <div class="container">
            <div class="main-header-three__top-inner">
                <div class="main-header-three__top-left">
                    <p class="main-header-three__top-left-text">All Kind of Waterproofing Treatment. <a href="enquiry.php"> Get A Quote Today!</a></p>
                </div>
                <div>
                    <a href="mailto:rkwaterproofingandcompanybpl@gmail.com"><i class="icon-email"> rkwaterproofingandcompanybpl@gmail.com</i></a>
                </div>
              	<div>
                    <a href="tel:+91 7554134061"><i class="icon-telephone"> <strong>+91 7554134061</strong></i></a>
                </div>
                <div class="main-header-three__top-social">
                    <a href="https://www.facebook.com/profile.php?id=100090751406407"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-google-plus-g"></i></a>
                    <a href="https://www.instagram.com/rkwaterproofingandcompany/"><i class="fab fa-instagram"></i></a>
                    <a href="https://www.linkedin.com/in/rk-waterproofing-and-company-00262b272/"><i class="fab fa-linkedin-in"></i></a>
                </div>
            </div>
        </div>
    </div>
    <div class="main-header-three__middle">
        <div class="container">
            <div class="main-header-three__middle-inner">
                <div class="main-header-three__logo">
                    <a href="index.php"><img src="assets/images/resources/logo-2.png" alt="" width="350"></a>
                </div>
                <div class="main-header-three__contact-box">
                    <ul class="list-unstyled main-header-three__contact-list">
                        <li>
                            <div class="icon">
                                <a href="http://wa.me/919669967206" target="_blank"><span class="fab fa-whatsapp text-green"></span></a>
                            </div>
                        </li>
                        <li>
                            <div class="icon">
                                <span class="icon-telephone"></span>
                            </div>
                            <div class="content">
                                <h5>Call Us</h5>
                                <p><a href="tel:+91 9669967206">+91 9669967206</a></p>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <nav class="main-menu main-menu-three">
        <div class="main-menu-three__wrapper">
            <div class="container">
                <div class="main-menu-three__wrapper-inner">
                    <div class="main-menu-three__left">
                        <div class="main-menu-three__main-menu-box">
                            <a href="#" class="mobile-nav__toggler"><i class="fa fa-bars"></i></a>
                            <ul class="main-menu__list">
                                <li><a href="index.php">Home </a></li>
                                <li><a href="about.php">About Us</a></li>
                                <li><a href="services.php">Services</a></li>
                                <li class="dropdown">
                                    <a href="work.php">Our Work</a>
                                    <ul>
                                        <li><a href="work.php">Terrace Water Proofing</a></li>
                                        <li><a href="work.php">Basement Water Proofing</a></li>
                                        <li><a href="work.php">Terrace Garden System</a></li>
                                        <li><a href="work.php">Sunken Water Proofing</a></li>
                                        <li><a href="work.php">Water Tank Water Proofing</a></li>
                                        <li><a href="work.php">Swimming Pool Water Proofing</a></li>
                                        <li><a href="work.php">Injection Grouting</a></li>
                                        <li><a href="work.php">Expansion Joint Work</a></li>
                                        <li><a href="work.php"> Waterproofing Material</a></li>
                                        <li><a href="work.php">Construction Chemicals</a></li>
                                        <li><a href="work.php">Painting Work</a></li>
                                        <li><a href="work.php">Protective Coating</a></li>
                                        <li><a href="work.php">Heat Insulating Coating</a></li>
                                        <li><a href="work.php">Capillary Waterproofing</a></li>
                                        <li><a href="work.php">Interior & Exterior Wall Treatment</a></li>
                                        <li><a href="work.php">Old & New Building Joint Works</a></li>

                                    </ul>
                                </li>
                                <li><a href="gallery.php">Gallery</a></li>
                                <li><a href="contact.php">Contact Us</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="main-menu-three__right">
                        <div class="main-menu-three__btn-box">
                            <a href="enquiry.php" class="thm-btn main-menu-three__btn">Enquiry</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </nav>
</header>

<div class="stricky-header stricked-menu main-menu main-menu-three">
    <div class="sticky-header__content"></div><!-- /.sticky-header__content -->
</div><!-- /.stricky-header -->

<!--Page Header Start-->
<section class="page-header">
    <div class="page-header-bg" style="background-image: url(assets/images/backgrounds/page-header-bg.png);">
    </div>
    <div class="container">
        <div class="page-header__inner">
            <div class="page-header__shape-1 float-bob-y">
                <img src="assets/images/shapes/page-header-shape-1.png">
            </div>
            <h2>Services</h2>
            <ul class="thm-breadcrumb list-unstyled">
                <li><a href="index.php">Home</a></li>
                <li><span>/</span></li>
                <li>Services</li>
            </ul>
        </div>
    </div>
</section>
<!--Page Header End-->


<!--liquid membrane Start-->
<section class="project-details">
    <div class="container">
        <div class="section-title text-center">
            <h2 class="section-title__title">Our Services</h2>
            <p class="services-three__text">With skilled and qualified professionals at work, we are experts at tackling the most challenging waterproofing challenges and this confidence in our work inspires us to continue growing in every department.</p>
        </div>
        <div class="project-details__top">
            <div class="row">
                <div class="project-description">
                    <h3 class="project-description__title">Liquid Membrane System</h3>
                    <p class="project-description__text-1">Liquid Membranes generally consist of a thin film separating two phases, which may be aqueous solutions or gas mixtures. Liquid-Applied Membrane (LAM) is a monolithic, fully-bonded, liquid-based coating suitable for many waterproofing and roofing applications.It can be used for new projects in all areas of roofing, planters, sunken areas, landscapes, pedestrian areas, car parks and structural waterproofing. LAM's are preferred products for corrugated roofing sheets and especially in projects where heating is not allowed like Refineries etc.</p>
                </div>
            </div>
            <div class="row mt-3">
                <!--Project Page Two Single Start-->
                <div class="col-xl-4 col-lg-6 col-md-6">
                    <div class="project-page-two__single">
                        <div class="project-page-two__img">
                            <img src="assets/images/services/liquid-membrane/liq1.jpg">
                            <div class="project-page-two__button">
                                <a class="img-popup" href="assets/images/services/liquid-membrane/liq1.jpg">
                                    <img src="assets/images/icon/icon-zoom-1.png">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--Project Page Two Single End-->

                <!--Project Page Two Single Start-->
                <div class="col-xl-4 col-lg-6 col-md-6">
                    <div class="project-page-two__single">
                        <div class="project-page-two__img">
                            <img src="assets/images/services/liquid-membrane/liq2.jpg">
                            <div class="project-page-two__button">
                                <a class="img-popup" href="assets/images/services/liquid-membrane/liq2.jpg">
                                    <img src="assets/images/icon/icon-zoom-1.png">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--Project Page Two Single End-->

                <!--Project Page Two Single Start-->
                <div class="col-xl-4 col-lg-6 col-md-6">
                    <div class="project-page-two__single">
                        <div class="project-page-two__img">
                            <img src="assets/images/services/liquid-membrane/liq3.jpg">
                            <div class="project-page-two__button">
                                <a class="img-popup" href="assets/images/services/liquid-membrane/liq3.jpg">
                                    <img src="assets/images/icon/icon-zoom-1.png">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--Project Page Two Single End-->
            </div>
        </div>
    </div>
</section>
<!--liquid membrane End-->

<!--Cementatious Coating Start-->
<section class="what-we-did">
    <div class="container">
        <div class="project-details__top">
            <div class="row">
                <div class="project-description">
                    <h3 class="project-description__title">Cementatious Coating</h3>
                    <p class="project-description__text-1">Cementatious Waterproofing Coatings are types of breathable coatings that can give concrete and masonry surfaces positive- and negative-side waterproofing. Cementatious products are considered some of the easiest waterproofing materials to mix and apply, and they provide a very solid and durable coating when acrylic additives are mixed into the cement. The materials involved are easy to obtain, and are particularly suited to wet areas like bathrooms.</p>
                    
                </div>
            </div>
            <div class="row mt-3">
                <!--Project Page Two Single Start-->
                <div class="col-xl-4 col-lg-6 col-md-6">
                    <div class="project-page-two__single">
                        <div class="project-page-two__img">
                            <img src="assets/images/services/cementatious-coating/cement1.jpg">
                            <div class="project-page-two__button">
                                <a class="img-popup" href="assets/images/services/cementatious-coating/cement1.jpg">
                                    <img src="assets/images/icon/icon-zoom-1.png">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--Project Page Two Single End-->

                <!--Project Page Two Single Start-->
                <div class="col-xl-4 col-lg-6 col-md-6">
                    <div class="project-page-two__single">
                        <div class="project-page-two__img">
                            <img src="assets/images/services/cementatious-coating/cement3.jpg">
                            <div class="project-page-two__button">
                                <a class="img-popup" href="assets/images/services/cementatious-coating/cement3.jpg">
                                    <img src="assets/images/icon/icon-zoom-1.png">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--Project Page Two Single End-->

                <!--Project Page Two Single Start-->
                <div class="col-xl-4 col-lg-6 col-md-6">
                    <div class="project-page-two__single">
                        <div class="project-page-two__img">
                            <img src="assets/images/services/cementatious-coating/cement2.jpg">
                            <div class="project-page-two__button">
                                <a class="img-popup" href="assets/images/services/cementatious-coating/cement2.jpg">
                                    <img src="assets/images/icon/icon-zoom-1.png">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--Project Page Two Single End-->
            </div>
        </div>
    </div>
</section>
<!--Cementatious Coating End-->

<!--Heat Insulating Coating Start-->
<section class="project-details">
    <div class="container">
        <div class="project-details__top">
            <div class="row">
                <div class="project-description">
                    <h3 class="project-description__title">Heat Insulating Coating</h3>
                    <p class="project-description__text-1">Heat Insulating Coating is a unique formulation based on grafted copolymer technology. It offers excellent long lasting heat reflective properties along with waterproofing and corrosion protection properties. It promises to reduce transfer of heat from outside to inside and makes the houses, working places, flooring etc. comfortable by keeping them cool in summer.It saves air conditioning and power energy cost and structure maintenance cost.</p>
                    
                </div>
            </div>
            <div class="row mt-3">
                <!--Project Page Two Single Start-->
                <div class="col-xl-4 col-lg-6 col-md-6">
                    <div class="project-page-two__single">
                        <div class="project-page-two__img">
                            <img src="assets/images/services/heat-insulating/heat2.jpg">
                            <div class="project-page-two__button">
                                <a class="img-popup" href="assets/images/services/heat-insulating/heat2.jpg">
                                    <img src="assets/images/icon/icon-zoom-1.png">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--Project Page Two Single End-->

                <!--Project Page Two Single Start-->
                <div class="col-xl-4 col-lg-6 col-md-6">
                    <div class="project-page-two__single">
                        <div class="project-page-two__img">
                            <img src="assets/images/services/heat-insulating/heat1.jpg">
                            <div class="project-page-two__button">
                                <a class="img-popup" href="assets/images/services/heat-insulating/heat1.jpg">
                                    <img src="assets/images/icon/icon-zoom-1.png">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--Project Page Two Single End-->

                <!--Project Page Two Single Start-->
                <div class="col-xl-4 col-lg-6 col-md-6">
                    <div class="project-page-two__single">
                        <div class="project-page-two__img">
                            <img src="assets/images/services/heat-insulating/heat3.jpg">
                            <div class="project-page-two__button">
                                <a class="img-popup" href="assets/images/services/heat-insulating/heat3.jpg">
                                    <img src="assets/images/icon/icon-zoom-1.png">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--Project Page Two Single End-->
            </div>
        </div>
    </div>
</section>
<!--Heat Insulating Coating End-->

<!--Decorative Coating Start-->
<section class="what-we-did">
    <div class="container">
        <div class="project-details__top">
            <div class="row">
                <div class="project-description">
                    <h3 class="project-description__title">Decorative Coating</h3>
                    <p class="project-description__text-1"> Decorative Coatings are applied to the interior and exterior surfaces of residential, commercial, institutional and industrial buildings. These coatings are used at room temperature. On the basis of their usage for aesthetic and protective purposes, decorative coatings can be categorized into surface preparatory products such as putty and primer; and paints used for aesthetic and protective purposes, namely, top coat and base coat.</p>
                    
                </div>
            </div>
            <div class="row mt-3">
                <!--Project Page Two Single Start-->
                <div class="col-xl-4 col-lg-6 col-md-6">
                    <div class="project-page-two__single">
                        <div class="project-page-two__img">
                            <img src="assets/images/services/decorative/dec3.jpg">
                            <div class="project-page-two__button">
                                <a class="img-popup" href="assets/images/services/decorative/dec3.jpg">
                                    <img src="assets/images/icon/icon-zoom-1.png">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--Project Page Two Single End-->

                <!--Project Page Two Single Start-->
                <div class="col-xl-4 col-lg-6 col-md-6">
                    <div class="project-page-two__single">
                        <div class="project-page-two__img">
                            <img src="assets/images/services/decorative/dec2.jpg">
                            <div class="project-page-two__button">
                                <a class="img-popup" href="assets/images/services/decorative/dec2.jpg">
                                    <img src="assets/images/icon/icon-zoom-1.png">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--Project Page Two Single End-->

                <!--Project Page Two Single Start-->
                <div class="col-xl-4 col-lg-6 col-md-6">
                    <div class="project-page-two__single">
                        <div class="project-page-two__img">
                            <img src="assets/images/services/decorative/dec1.jpg">
                            <div class="project-page-two__button">
                                <a class="img-popup" href="assets/images/services/decorative/dec1.jpg">
                                    <img src="assets/images/icon/icon-zoom-1.png">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--Project Page Two Single End-->
            </div>
        </div>
    </div>
</section>
<!--Decorative Coating End-->

<!--Expansion joint treatment Start-->
<section class="project-details">
    <div class="container">
        <div class="project-details__top">
            <div class="row">
                <div class="project-description">
                    <h3 class="project-description__title">Expansion Joint Treatment</h3>
                    <p class="project-description__text-1">An Expansion Joint (also referred to as a movement joint) is a planned joint which is designed to allow two sections of concrete or masonry to expand and contract.Expansion joints are incredibly useful when laying new concrete or reinforced concrete within an area bounded by walls or buildings.The key function of waterproofing an expansion joint is to minimize water ingress into a structure by creating a secure waterproofing barrier.  Penetrating water may cause damage and may reduce the usage and lifecycle of the building.</p>
                    
                </div>
            </div>
            <div class="row mt-3">
                <!--Project Page Two Single Start-->
                <div class="col-xl-4 col-lg-6 col-md-6">
                    <div class="project-page-two__single">
                        <div class="project-page-two__img">
                            <img src="assets/images/services/expansion-joints/exj1.jpg">
                            <div class="project-page-two__button">
                                <a class="img-popup" href="assets/images/services/expansion-joints/exj1.jpg">
                                    <img src="assets/images/icon/icon-zoom-1.png">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--Project Page Two Single End-->

                <!--Project Page Two Single Start-->
                <div class="col-xl-4 col-lg-6 col-md-6">
                    <div class="project-page-two__single">
                        <div class="project-page-two__img">
                            <img src="assets/images/services/expansion-joints/exj2.jpg">
                            <div class="project-page-two__button">
                                <a class="img-popup" href="assets/images/services/expansion-joints/exj2.jpg">
                                    <img src="assets/images/icon/icon-zoom-1.png">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--Project Page Two Single End-->
                <!--Project Page Two Single Start-->
                <div class="col-xl-4 col-lg-6 col-md-6">
                    <div class="project-page-two__single">
                        <div class="project-page-two__img">
                            <img src="assets/images/services/expansion-joints/exj3.jpg">
                            <div class="project-page-two__button">
                                <a class="img-popup" href="assets/images/services/expansion-joints/exj3.jpg">
                                    <img src="assets/images/icon/icon-zoom-1.png">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--Project Page Two Single End-->
            </div>
        </div>
    </div>
</section>
<!--Expansion joint treatment End-->

<!--Injection Grouting Start-->
<section class="what-we-did">
    <div class="container">
        <div class="project-details__top">
            <div class="row">
                <div class="project-description">
                    <h3 class="project-description__title">Injection Grouting</h3>
                    <p class="project-description__text-1">Injection Grouting is the method of filling the cracks, open joints, voids, or honeycombs, in concrete or masonry structural members. This is done under pressure with a grout material that cures in place to produce the desired results like strengthening a structure and preventing water ingress.</p>
                    
                </div>
            </div>
            <div class="row mt-3">
                <!--Project Page Two Single Start-->
                <div class="col-xl-4 col-lg-6 col-md-6">
                    <div class="project-page-two__single">
                        <div class="project-page-two__img">
                            <img src="assets/images/services/injection-grouting/injection1.jpg">
                            <div class="project-page-two__button">
                                <a class="img-popup" href="assets/images/services/injection-grouting/injection1.jpg">
                                    <img src="assets/images/icon/icon-zoom-1.png">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--Project Page Two Single End-->

                <!--Project Page Two Single Start-->
                <div class="col-xl-4 col-lg-6 col-md-6">
                    <div class="project-page-two__single">
                        <div class="project-page-two__img">
                            <img src="assets/images/services/injection-grouting/injection2.jpg">
                            <div class="project-page-two__button">
                                <a class="img-popup" href="assets/images/services/injection-grouting/injection2.jpg">
                                    <img src="assets/images/icon/icon-zoom-1.png">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--Project Page Two Single End-->
                <!--Project Page Two Single Start-->
                <div class="col-xl-4 col-lg-6 col-md-6">
                    <div class="project-page-two__single">
                        <div class="project-page-two__img">
                            <img src="assets/images/services/injection-grouting/injection3.jpg">
                            <div class="project-page-two__button">
                                <a class="img-popup" href="assets/images/services/injection-grouting/injection3.jpg">
                                    <img src="assets/images/icon/icon-zoom-1.png">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--Project Page Two Single End-->
            </div>
        </div>
    </div>
</section>
<!--Injection Grouting End-->

<!--Waterproofing Start-->
<section class="project-details">
    <div class="container">
        <div class="project-details__top">
            <div class="row">
                <div class="project-description">
                    <h3 class="project-description__title">Waterproofing Work</h3>
                    <p class="project-description__text-1">Waterproofing is a method which prevents water from penetrating your house. Waterproofing is very important as it helps keep your house dry. It helps reduce humidity inside the house and thereby protects things inside your house from damage caused due to humidity or water exposure.</p>
                    
                </div>
            </div>
            <div class="row mt-3">
                <!--Project Page Two Single Start-->
                <div class="col-xl-4 col-lg-6 col-md-6">
                    <div class="project-page-two__single">
                        <div class="project-page-two__img">
                            <img src="assets/images/services/waterproofing/water2.jpg">
                            <div class="project-page-two__button">
                                <a class="img-popup" href="assets/images/services/waterproofing/water2.jpg">
                                    <img src="assets/images/icon/icon-zoom-1.png">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--Project Page Two Single End-->

                <!--Project Page Two Single Start-->
                <div class="col-xl-4 col-lg-6 col-md-6">
                    <div class="project-page-two__single">
                        <div class="project-page-two__img">
                            <img src="assets/images/services/waterproofing/water1.jpg">
                            <div class="project-page-two__button">
                                <a class="img-popup" href="assets/images/services/waterproofing/water1.jpg">
                                    <img src="assets/images/icon/icon-zoom-1.png">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--Project Page Two Single End-->
                <!--Project Page Two Single Start-->
                <div class="col-xl-4 col-lg-6 col-md-6">
                    <div class="project-page-two__single">
                        <div class="project-page-two__img">
                            <img src="assets/images/services/waterproofing/water3.jpg">
                            <div class="project-page-two__button">
                                <a class="img-popup" href="assets/images/services/waterproofing/water3.jpg">
                                    <img src="assets/images/icon/icon-zoom-1.png">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--Project Page Two Single End-->
            </div>
        </div>
    </div>
</section>
<!-- Waterproofing end -->

<!--Protective Coating Start-->
<section class="what-we-did">
    <div class="container">
        <div class="project-details__top">
            <div class="row">
                <div class="project-description">
                    <h3 class="project-description__title">Protective Coating</h3>
                    <p class="project-description__text-1">A Protective Coating is a layer of material applied to the surface of another material with the intent of inhibiting or preventing corrosion. A protective Coating may be metallic or non-metallic.Protective coatings are applied using a variety of methods, and can be used for many other purposes besides corrosion prevention.</p>
                    
                </div>
            </div>
            <div class="row mt-3">
                <!--Project Page Two Single Start-->
                <div class="col-xl-4 col-lg-6 col-md-6">
                    <div class="project-page-two__single">
                        <div class="project-page-two__img">
                            <img src="assets/images/services/protective/protective1.jpg">
                            <div class="project-page-two__button">
                                <a class="img-popup" href="assets/images/services/protective/protective1.jpg">
                                    <img src="assets/images/icon/icon-zoom-1.png">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--Project Page Two Single End-->

                <!--Project Page Two Single Start-->
                <div class="col-xl-4 col-lg-6 col-md-6">
                    <div class="project-page-two__single">
                        <div class="project-page-two__img">
                            <img src="assets/images/services/protective/protective2.jpg">
                            <div class="project-page-two__button">
                                <a class="img-popup" href="assets/images/services/protective/protective2.jpg">
                                    <img src="assets/images/icon/icon-zoom-1.png">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--Project Page Two Single End-->
                <!--Project Page Two Single Start-->
                <div class="col-xl-4 col-lg-6 col-md-6">
                    <div class="project-page-two__single">
                        <div class="project-page-two__img">
                            <img src="assets/images/services/protective/protective3.jpg">
                            <div class="project-page-two__button">
                                <a class="img-popup" href="assets/images/services/protective/protective3.jpg">
                                    <img src="assets/images/icon/icon-zoom-1.png">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--Project Page Two Single End-->
            </div>
        </div>
    </div>
</section>
<!--Protective Coating End-->

<!--BrickBat Koba Start-->
<section class="project-details">
    <div class="container">
        <div class="project-details__top">
            <div class="row">
                <div class="project-description">
                    <h3 class="project-description__title">BrickBat Koba Waterproofing</h3>
                    <p class="project-description__text-1">Brickbat Coba waterproofing is an efficient method of providing waterproofing and insulating for thermal comfort on flat RCC roofs. It is one of the oldest waterproofing technologies, including the installation of brickbats on a flat RCC roof & grouting them with a waterproofing solution with a slope to drain groundwater.</p>
                    
                </div>
            </div>
            <div class="row mt-3">
                <!--Project Page Two Single Start-->
                <div class="col-xl-4 col-lg-6 col-md-6">
                    <div class="project-page-two__single">
                        <div class="project-page-two__img">
                            <img src="assets/images/services/bat1.jpg">
                            <div class="project-page-two__button">
                                <a class="img-popup" href="assets/images/services/bat1.jpg">
                                    <img src="assets/images/icon/icon-zoom-1.png">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--Project Page Two Single End-->

                <!--Project Page Two Single Start-->
                <div class="col-xl-4 col-lg-6 col-md-6">
                    <div class="project-page-two__single">
                        <div class="project-page-two__img">
                            <img src="assets/images/services/bat2.jpg">
                            <div class="project-page-two__button">
                                <a class="img-popup" href="assets/images/services/bat2.jpg">
                                    <img src="assets/images/icon/icon-zoom-1.png">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--Project Page Two Single End-->
                <!--Project Page Two Single Start-->
                <div class="col-xl-4 col-lg-6 col-md-6">
                    <div class="project-page-two__single">
                        <div class="project-page-two__img">
                            <img src="assets/images/services/bat3.jpg">
                            <div class="project-page-two__button">
                                <a class="img-popup" href="assets/images/services/bat3.jpg">
                                    <img src="assets/images/icon/icon-zoom-1.png">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--Project Page Two Single End-->
            </div>
        </div>
    </div>
</section>
<!--BrickBat Koba End-->


<!--Kota Box Start-->
<section class="what-we-did">
    <div class="container">
        <div class="project-details__top">
            <div class="row">
                <div class="project-description">
                    <h3 class="project-description__title">Kota Box Waterproofing</h3>
                    <p class="project-description__text-1">It is also called Box type waterproofing. Kota Stone is a limestone and famous for its lowprice and beautiful colours. People like Kota Stones due to its charming appearance and longlife.You can use kota stone waterproofing method for your home basement or first floor, car garage, bathroom walls and floor, sewage areas, water storage tanks, roof top, and kitchen area.</p>
                    
                </div>
            </div>
            <div class="row mt-3">
                <!--Project Page Two Single Start-->
                <div class="col-xl-4 col-lg-6 col-md-6">
                    <div class="project-page-two__single">
                        <div class="project-page-two__img">
                            <img src="assets/images/services/kota1.jpg">
                            <div class="project-page-two__button">
                                <a class="img-popup" href="assets/images/services/kota1.jpg">
                                    <img src="assets/images/icon/icon-zoom-1.png">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--Project Page Two Single End-->

                <!--Project Page Two Single Start-->
                <div class="col-xl-4 col-lg-6 col-md-6">
                    <div class="project-page-two__single">
                        <div class="project-page-two__img">
                            <img src="assets/images/services/kota2.jpg">
                            <div class="project-page-two__button">
                                <a class="img-popup" href="assets/images/services/kota2.jpg">
                                    <img src="assets/images/icon/icon-zoom-1.png">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--Project Page Two Single End-->
                <!--Project Page Two Single Start-->
                <div class="col-xl-4 col-lg-6 col-md-6">
                    <div class="project-page-two__single">
                        <div class="project-page-two__img">
                            <img src="assets/images/services/kota3.jpg">
                            <div class="project-page-two__button">
                                <a class="img-popup" href="assets/images/services/kota3.jpg">
                                    <img src="assets/images/icon/icon-zoom-1.png">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--Project Page Two Single End-->
            </div>
        </div>
    </div>
</section>
<!--Kota Box End-->


<!--China mosaic Start-->
<section class="project-details">
    <div class="container">
        <div class="project-details__top">
            <div class="row">
                <div class="project-description">
                    <h3 class="project-description__title">China Mosaic Tile Fitting</h3>
                    <p class="project-description__text-1">Flooring which has a mixture of stones and glass chips with an attractive finish and multicolour flooring called as a China Mosaic flooring. Mosaic tile is a simple way to add visual interest to any wall, floor or space.These tiles can be made from stones, like travertine, marble or pebbles, or glass, metal, porcelain, and more.</p>
                    
                </div>
            </div>
            <div class="row mt-3">
                <!--Project Page Two Single Start-->
                <div class="col-xl-4 col-lg-6 col-md-6">
                    <div class="project-page-two__single">
                        <div class="project-page-two__img">
                            <img src="assets/images/services/china1.jpg">
                            <div class="project-page-two__button">
                                <a class="img-popup" href="assets/images/services/china1.jpg">
                                    <img src="assets/images/icon/icon-zoom-1.png">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--Project Page Two Single End-->

                <!--Project Page Two Single Start-->
                <div class="col-xl-4 col-lg-6 col-md-6">
                    <div class="project-page-two__single">
                        <div class="project-page-two__img">
                            <img src="assets/images/services/china2.jpg">
                            <div class="project-page-two__button">
                                <a class="img-popup" href="assets/images/services/china2.jpg">
                                    <img src="assets/images/icon/icon-zoom-1.png">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--Project Page Two Single End-->
                <!--Project Page Two Single Start-->
                <div class="col-xl-4 col-lg-6 col-md-6">
                    <div class="project-page-two__single">
                        <div class="project-page-two__img">
                            <img src="assets/images/services/china3.jpg">
                            <div class="project-page-two__button">
                                <a class="img-popup" href="assets/images/services/china3.jpg">
                                    <img src="assets/images/icon/icon-zoom-1.png">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--Project Page Two Single End-->
            </div>
        </div>
    </div>
</section>
<!--China mosaic End-->


<!--Site Footer Start-->
<footer class="site-footer">
    <div class="site-footer__shape-1 float-bob-x">
        <img src="assets/images/shapes/site-footer-shape-1.png">
    </div>
    <div class="site-footer__top">
        <div class="container">
            <div class="site-footer__inner">
                <div class="site-footer__contact-info">
                    <ul class="site-footer__contact-points list-unstyled">
                        <li>
                            <div class="icon">
                                <span class="icon-location"></span>
                            </div>
                            <div class="content">
                                <h4>Address :</h4>
                                <p>E-8/67, Basantkunj, Shahpura, Bhopal-462039</p>
                            </div>
                        </li>
                        <li>
                            <div class="icon">
                                <span class="icon-email"></span>
                            </div>
                            <div class="content">
                                <h4>Email us :</h4>
                                <a href="mailto:rkwaterproofingandcompanybpl@gmail.com">rkwaterproofingandcompanybpl@gmail.com</a>
                            </div>
                        </li>
                        <li>
                            <div class="icon">
                                <span class="icon-telephone"></span>
                            </div>
                            <div class="content">
                                <h4>Call us on :</h4>
                                <a href="tel:+91 9669967206">+91 9669967206</a>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="site-footer__middle">
        <div class="container">
            <div class="row">
                <div class="col-xl-4 col-lg-6 col-md-6 wow fadeInUp" data-wow-delay="100ms">
                    <div class=" footer-widget__column footer-widget__img-box">
                        <div class="footer-widget__img">
                            <img src="assets/images/resources/footer-widget-img-1.png">
                        </div>
                    </div>
                </div>
                <div class="col-xl-2 col-lg-6 col-md-6 wow fadeInUp" data-wow-delay="200ms">
                    <div class="footer-widget__column footer-widget__useful-links">
                        <div class="footer-widget__title-box">
                            <h3 class="footer-widget__title">Quick Links</h3>
                        </div>
                        <ul class="footer-widget__useful-links-list list-unstyled">
                            <li><a href="index.php">Home </a></li>
                            <li><a href="about.php">About Us</a></li>
                            <li><a href="services.php">Services</a></li>
                            <li><a href="work.php">Our Work</a></li>
                            <li><a href="gallery.php">Gallery</a></li>
                            <li><a href="contact.php">Contact Us</a></li>
                        </ul>
                    </div>
                    <div class="site-footer__social">
                       <a href="https://www.facebook.com/profile.php?id=100090751406407"><i class="fab fa-facebook-f"></i></a>
                        <a href="#"><i class="fab fa-google-plus-g"></i></a>
                        <a href="https://www.instagram.com/rkwaterproofingandcompany/"><i class="fab fa-instagram"></i></a> 
                        <a href="https://www.linkedin.com/in/rk-waterproofing-and-company-00262b272/"><i class="fab fa-linkedin-in"></i></a>                  
                    </div>
                </div>
                <div class="col-xl-3 col-lg-6 col-md-6 wow fadeInUp" data-wow-delay="300ms">
                    <div class="footer-widget__column footer-widget__services">
                        <div class="footer-widget__title-box">
                            <h3 class="footer-widget__title">Work we do</h3>
                        </div>
                        <ul class="footer-widget__useful-links-list list-unstyled">
                            <li><a href="work.php">Terrace Water Proofing</a></li>
                            <li><a href="work.php">Basement Water Proofing</a></li>
                            <li><a href="work.php">Terrace Garden System</a></li>
                            <li><a href="work.php">Sunken Water Proofing</a></li>
                            <li><a href="work.php">Water Tank Water Proofing</a></li>
                            <li><a href="work.php">Swimming Pool Water Proofing</a></li>
                            <li><a href="work.php">Injection Grouting</a></li>
                            <li><a href="work.php">Expansion Joint Work</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-6 col-md-6 wow fadeInUp" data-wow-delay="400ms">
                    <div class="footer-widget__column footer-widget__services">
                        <div class="footer-widget__title-box">
                            <h3 class="footer-widget__title">Work we do</h3>
                        </div>
                        <ul class="footer-widget__useful-links-list list-unstyled">
                            
                            <li><a href="work.php"> Waterproofing Work</a></li>
                            <li><a href="work.php">Painting Work</a></li>
                          	<li><a href="work.php">Heat Insulating Coating</a></li>
                            <li><a href="work.php">Protective Coating</a></li>
                            <li><a href="work.php">Construction Chemicals</a></li>
                            <li><a href="work.php">Capillary Waterproofing</a></li>
                            <li><a href="work.php">Interior & Exterior Wall Treatment</a></li>
                            <li><a href="work.php">Old & New Building Joint Works</a></li>
                        </ul>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
    <div class="site-footer__bottom">
        <div class="container">
            <div class="row">
                <div class="col-xl-12">
                    <div class="site-footer__bottom-inner">
                        <p class="site-footer__bottom-text">Copyright © 2024  <a href="#">R.K. Waterproofing and Company</a>. All right reserved | Designed & Developed by: <a href="https://ginfosoft.com/" target="_blank">G-INFOSOFT TECHNOLOGIES</a></p>
                        <!-- <div class="site-footer__bottom-text-two">
                            <a href="#!">Purchase Now</a>
                        </div> -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<!--Site Footer End-->


</div><!-- /.page-wrapper -->


<div class="mobile-nav__wrapper">
    <div class="mobile-nav__overlay mobile-nav__toggler"></div>
    <!-- /.mobile-nav__overlay -->
    <div class="mobile-nav__content">
        <span class="mobile-nav__close mobile-nav__toggler"><i class="fa fa-times"></i></span>

        <div class="logo-box">
            <a href="index.html" aria-label="logo image"><img src="assets/images/resources/logo-1.png" width="200"
                    /></a>
        </div>
        <!-- /.logo-box -->
        <div class="mobile-nav__container"></div>
        <!-- /.mobile-nav__container -->

        <ul class="mobile-nav__contact list-unstyled">
            <li>
                <i class="fa fa-envelope"></i>
                <a href="mailto:rkwaterproofingandcompanybpl@gmail.com">rkwaterproofingandcompanybpl@gmail.com</a>
            </li>
            <li>
                <i class="fa fa-phone-alt"></i>
                <a href="tel:666-888-0000">+91 9669967206</a>
            </li>
        </ul><!-- /.mobile-nav__contact -->
        <div class="mobile-nav__top">
            <div class="mobile-nav__social">
                <a href="#" class="fab fa-twitter"></a>
                <a href="#" class="fab fa-facebook-square"></a>
                <a href="#" class="fab fa-instagram"></a>
            </div><!-- /.mobile-nav__social -->
        </div><!-- /.mobile-nav__top -->



    </div>
    <!-- /.mobile-nav__content -->
</div>
<!-- /.mobile-nav__wrapper -->

    

<a href="#" data-target="html" class="scroll-to-target scroll-to-top"><i class="fa fa-angle-up"></i></a>


<script src="assets/vendors/jquery/jquery-3.6.0.min.js"></script>
<script src="assets/vendors/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/vendors/jarallax/jarallax.min.js"></script>
<script src="assets/vendors/jquery-ajaxchimp/jquery.ajaxchimp.min.js"></script>
<script src="assets/vendors/jquery-appear/jquery.appear.min.js"></script>
<script src="assets/vendors/jquery-circle-progress/jquery.circle-progress.min.js"></script>
<script src="assets/vendors/jquery-magnific-popup/jquery.magnific-popup.min.js"></script>
<script src="assets/vendors/jquery-validate/jquery.validate.min.js"></script>
<script src="assets/vendors/nouislider/nouislider.min.js"></script>
<script src="assets/vendors/odometer/odometer.min.js"></script>
<script src="assets/vendors/swiper/swiper.min.js"></script>
<script src="assets/vendors/tiny-slider/tiny-slider.min.js"></script>
<script src="assets/vendors/wnumb/wNumb.min.js"></script>
<script src="assets/vendors/wow/wow.js"></script>
<script src="assets/vendors/isotope/isotope.js"></script>
<script src="assets/vendors/countdown/countdown.min.js"></script>
<script src="assets/vendors/owl-carousel/owl.carousel.min.js"></script>
<script src="assets/vendors/bxslider/jquery.bxslider.min.js"></script>
<script src="assets/vendors/bootstrap-select/js/bootstrap-select.min.js"></script>
<script src="assets/vendors/vegas/vegas.min.js"></script>
<script src="assets/vendors/jquery-ui/jquery-ui.js"></script>
<script src="assets/vendors/timepicker/timePicker.js"></script>
<script src="assets/vendors/circleType/jquery.circleType.js"></script>
<script src="assets/vendors/circleType/jquery.lettering.min.js"></script>
<script src="assets/vendors/sidebar-content/jquery-sidebar-content.js"></script>


<script src="assets/vendors/tweenmax/TweenMax.min.js"></script>
<!-- Template js -->
<script src="assets/js/endreox.js"></script>

</body>
</html>