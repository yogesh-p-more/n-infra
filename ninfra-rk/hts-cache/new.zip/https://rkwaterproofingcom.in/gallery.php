<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>R.K. Waterproofing and Company</title>
<link rel="icon" type="image/png" sizes="32x32" href="assets/images/favicons/favicon-32x32.png" />
<meta name="description" content="R.K. Waterproofing and Company" />
<link rel="preconnect" href="https://fonts.googleapis.com/">
<link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
<link
    href="https://fonts.googleapis.com/css2?family=Barlow:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&amp;display=swap"
    rel="stylesheet">
<link
    href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&amp;display=swap"
    rel="stylesheet">
<link
    href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&amp;display=swap"
    rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Yantramanav:wght@100;300;400;500;700;900&amp;display=swap"
    rel="stylesheet">

<link rel="stylesheet" href="assets/vendors/bootstrap/css/bootstrap.min.css" />
<link rel="stylesheet" href="assets/vendors/animate/animate.min.css" />
<link rel="stylesheet" href="assets/vendors/animate/custom-animate.css" />
<link rel="stylesheet" href="assets/vendors/fontawesome/css/all.min.css" />
<link rel="stylesheet" href="assets/vendors/jarallax/jarallax.css" />
<link rel="stylesheet" href="assets/vendors/jquery-magnific-popup/jquery.magnific-popup.css" />
<link rel="stylesheet" href="assets/vendors/nouislider/nouislider.min.css" />
<link rel="stylesheet" href="assets/vendors/nouislider/nouislider.pips.css" />
<link rel="stylesheet" href="assets/vendors/odometer/odometer.min.css" />
<link rel="stylesheet" href="assets/vendors/swiper/swiper.min.css" />
<link rel="stylesheet" href="assets/vendors/endreox-icons/style.css">
<link rel="stylesheet" href="assets/vendors/tiny-slider/tiny-slider.min.css" />
<link rel="stylesheet" href="assets/vendors/reey-font/stylesheet.css" />
<link rel="stylesheet" href="assets/vendors/owl-carousel/owl.carousel.min.css" />
<link rel="stylesheet" href="assets/vendors/owl-carousel/owl.theme.default.min.css" />
<link rel="stylesheet" href="assets/vendors/bxslider/jquery.bxslider.css" />
<link rel="stylesheet" href="assets/vendors/bootstrap-select/css/bootstrap-select.min.css" />
<link rel="stylesheet" href="assets/vendors/vegas/vegas.min.css" />
<link rel="stylesheet" href="assets/vendors/jquery-ui/jquery-ui.css" />
<link rel="stylesheet" href="assets/vendors/timepicker/timePicker.css" />
<link rel="stylesheet" href="assets/vendors/free-hand-font/stylesheet.css" />

<!-- template styles -->
<link rel="stylesheet" href="assets/css/endreox.css" />
<link rel="stylesheet" href="assets/css/endreox-responsive.css" />
</head>

<body class="custom-cursor">

    <div class="custom-cursor__cursor"></div>
    <div class="custom-cursor__cursor-two"></div>

<div class="page-wrapper">

<header class="main-header-three">
    <div class="main-header-three__top">
        <div class="container">
            <div class="main-header-three__top-inner">
                <div class="main-header-three__top-left">
                    <p class="main-header-three__top-left-text">All Kind of Waterproofing Treatment. <a href="enquiry.php"> Get A Quote Today!</a></p>
                </div>
                <div>
                    <a href="mailto:rkwaterproofingandcompanybpl@gmail.com"><i class="icon-email"> rkwaterproofingandcompanybpl@gmail.com</i></a>
                </div>
              	<div>
                    <a href="tel:+91 7554134061"><i class="icon-telephone"> <strong>+91 7554134061</strong></i></a>
                </div>
                <div class="main-header-three__top-social">
                    <a href="https://www.facebook.com/profile.php?id=100090751406407"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-google-plus-g"></i></a>
                    <a href="https://www.instagram.com/rkwaterproofingandcompany/"><i class="fab fa-instagram"></i></a>
                    <a href="https://www.linkedin.com/in/rk-waterproofing-and-company-00262b272/"><i class="fab fa-linkedin-in"></i></a>
                </div>
            </div>
        </div>
    </div>
    <div class="main-header-three__middle">
        <div class="container">
            <div class="main-header-three__middle-inner">
                <div class="main-header-three__logo">
                    <a href="index.php"><img src="assets/images/resources/logo-2.png" alt="" width="350"></a>
                </div>
                <div class="main-header-three__contact-box">
                    <ul class="list-unstyled main-header-three__contact-list">
                        <li>
                            <div class="icon">
                                <a href="http://wa.me/919669967206" target="_blank"><span class="fab fa-whatsapp text-green"></span></a>
                            </div>
                        </li>
                        <li>
                            <div class="icon">
                                <span class="icon-telephone"></span>
                            </div>
                            <div class="content">
                                <h5>Call Us</h5>
                                <p><a href="tel:+91 9669967206">+91 9669967206</a></p>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <nav class="main-menu main-menu-three">
        <div class="main-menu-three__wrapper">
            <div class="container">
                <div class="main-menu-three__wrapper-inner">
                    <div class="main-menu-three__left">
                        <div class="main-menu-three__main-menu-box">
                            <a href="#" class="mobile-nav__toggler"><i class="fa fa-bars"></i></a>
                            <ul class="main-menu__list">
                                <li><a href="index.php">Home </a></li>
                                <li><a href="about.php">About Us</a></li>
                                <li><a href="services.php">Services</a></li>
                                <li class="dropdown">
                                    <a href="work.php">Our Work</a>
                                    <ul>
                                        <li><a href="work.php">Terrace Water Proofing</a></li>
                                        <li><a href="work.php">Basement Water Proofing</a></li>
                                        <li><a href="work.php">Terrace Garden System</a></li>
                                        <li><a href="work.php">Sunken Water Proofing</a></li>
                                        <li><a href="work.php">Water Tank Water Proofing</a></li>
                                        <li><a href="work.php">Swimming Pool Water Proofing</a></li>
                                        <li><a href="work.php">Injection Grouting</a></li>
                                        <li><a href="work.php">Expansion Joint Work</a></li>
                                        <li><a href="work.php"> Waterproofing Material</a></li>
                                        <li><a href="work.php">Construction Chemicals</a></li>
                                        <li><a href="work.php">Painting Work</a></li>
                                        <li><a href="work.php">Protective Coating</a></li>
                                        <li><a href="work.php">Heat Insulating Coating</a></li>
                                        <li><a href="work.php">Capillary Waterproofing</a></li>
                                        <li><a href="work.php">Interior & Exterior Wall Treatment</a></li>
                                        <li><a href="work.php">Old & New Building Joint Works</a></li>

                                    </ul>
                                </li>
                                <li><a href="gallery.php">Gallery</a></li>
                                <li><a href="contact.php">Contact Us</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="main-menu-three__right">
                        <div class="main-menu-three__btn-box">
                            <a href="enquiry.php" class="thm-btn main-menu-three__btn">Enquiry</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </nav>
</header>

<div class="stricky-header stricked-menu main-menu main-menu-three">
    <div class="sticky-header__content"></div><!-- /.sticky-header__content -->
</div><!-- /.stricky-header -->
<!--Page Header Start-->
<section class="page-header">
    <div class="page-header-bg" style="background-image: url(assets/images/backgrounds/page-header-bg.png);">
    </div>
    <div class="container">
        <div class="page-header__inner">
            <div class="page-header__shape-1 float-bob-y">
                <img src="assets/images/shapes/page-header-shape-1.png">
            </div>
            <h2>Gallery</h2>
            <ul class="thm-breadcrumb list-unstyled">
                <li><a href="index.php">Home</a></li>
                <li><span>/</span></li>
                <li>Gallery</li>
            </ul>
        </div>
    </div>
</section>
<!--Page Header End-->

<!--Project Page One Start-->
<section class="project-page-one">
    <div class="project-page-one__bg"
        style="background-image: url(assets/images/backgrounds/project-page-one-bg.jpg);"></div>
    <div class="container-fluid">
        <div class="section-title text-center">
            <h2 class="section-title__title">Terrace Water Proofing</h2>
        </div>
        <div class="row filter-layout">
            <div class="col-xl-3 col-lg-6 col-md-6 filter-item">
                <div class="project-page-one__single">
                    <div class="project-page-one__img">
                        <img src="assets/images/work/liq1.jpg">
                        <div class="project-page-one__button">
                            <a class="img-popup" href="assets/images/work/liq1.jpg">
                                <img src="assets/images/icon/icon-zoom-1.png">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-6 col-md-6 filter-item">
                <div class="project-page-one__single">
                    <div class="project-page-one__img">
                        <img src="assets/images/work/tr1.jpg">
                        <div class="project-page-one__button">
                            <a class="img-popup" href="assets/images/work/tr1.jpg">
                                <img src="assets/images/icon/icon-zoom-1.png">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-6 col-md-6 filter-item">
                <div class="project-page-one__single">
                    <div class="project-page-one__img">
                        <img src="assets/images/work/tr2.jpg">
                        <div class="project-page-one__button">
                            <a class="img-popup" href="assets/images/work/tr2.jpg">
                                <img src="assets/images/icon/icon-zoom-1.png">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-6 col-md-6 filter-item">
                <div class="project-page-one__single">
                    <div class="project-page-one__img">
                        <img src="assets/images/work/tr3.jpg">
                        <div class="project-page-one__button">
                            <a class="img-popup" href="assets/images/work/tr3.jpg">
                                <img src="assets/images/icon/icon-zoom-1.png">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-6 col-md-6 filter-item">
                <div class="project-page-one__single">
                    <div class="project-page-one__img">
                        <img src="assets/images/work/tr5.jpg">
                        <div class="project-page-one__button">
                            <a class="img-popup" href="assets/images/work/tr5.jpg">
                                <img src="assets/images/icon/icon-zoom-1.png">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-6 col-md-6 filter-item">
                <div class="project-page-one__single">
                    <div class="project-page-one__img">
                        <img src="assets/images/work/tr4.jpg">
                        <div class="project-page-one__button">
                            <a class="img-popup" href="assets/images/work/tr4.jpg">
                                <img src="assets/images/icon/icon-zoom-1.png">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-6 col-md-6 filter-item">
                <div class="project-page-one__single">
                    <div class="project-page-one__img">
                        <img src="assets/images/work/tr7.jpg">
                        <div class="project-page-one__button">
                            <a class="img-popup" href="assets/images/work/tr7.jpg">
                                <img src="assets/images/icon/icon-zoom-1.png">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-6 col-md-6 filter-item">
                <div class="project-page-one__single">
                    <div class="project-page-one__img">
                        <img src="assets/images/work/tr6.jpg">
                        <div class="project-page-one__button">
                            <a class="img-popup" href="assets/images/work/tr6.jpg">
                                <img src="assets/images/icon/icon-zoom-1.png">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-6 col-md-6 filter-item">
                <div class="project-page-one__single">
                    <div class="project-page-one__img">
                        <img src="assets/images/work/tr8.jpg">
                        <div class="project-page-one__button">
                            <a class="img-popup" href="assets/images/work/tr8.jpg">
                                <img src="assets/images/icon/icon-zoom-1.png">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-6 col-md-6 filter-item">
                <div class="project-page-one__single">
                    <div class="project-page-one__img">
                        <img src="assets/images/work/tr9.jpg">
                        <div class="project-page-one__button">
                            <a class="img-popup" href="assets/images/work/tr9.jpg">
                                <img src="assets/images/icon/icon-zoom-1.png">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-6 col-md-6 filter-item">
                <div class="project-page-one__single">
                    <div class="project-page-one__img">
                        <img src="assets/images/work/tr10.jpg">
                        <div class="project-page-one__button">
                            <a class="img-popup" href="assets/images/work/tr10.jpg">
                                <img src="assets/images/icon/icon-zoom-1.png">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-6 col-md-6 filter-item">
                <div class="project-page-one__single">
                    <div class="project-page-one__img">
                        <img src="assets/images/work/tr11.jpg">
                        <div class="project-page-one__button">
                            <a class="img-popup" href="assets/images/work/tr11.jpg">
                                <img src="assets/images/icon/icon-zoom-1.png">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-6 col-md-6 filter-item">
                <div class="project-page-one__single">
                    <div class="project-page-one__img">
                        <img src="assets/images/work/tr12.jpg">
                        <div class="project-page-one__button">
                            <a class="img-popup" href="assets/images/work/tr12.jpg">
                                <img src="assets/images/icon/icon-zoom-1.png">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-6 col-md-6 filter-item">
                <div class="project-page-one__single">
                    <div class="project-page-one__img">
                        <img src="assets/images/work/tr13.jpg">
                        <div class="project-page-one__button">
                            <a class="img-popup" href="assets/images/work/tr13.jpg">
                                <img src="assets/images/icon/icon-zoom-1.png">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-6 col-md-6 filter-item">
                <div class="project-page-one__single">
                    <div class="project-page-one__img">
                        <img src="assets/images/work/tr14.jpg">
                        <div class="project-page-one__button">
                            <a class="img-popup" href="assets/images/work/tr14.jpg">
                                <img src="assets/images/icon/icon-zoom-1.png">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-6 col-md-6 filter-item">
                <div class="project-page-one__single">
                    <div class="project-page-one__img">
                        <img src="assets/images/work/tr15.jpg">
                        <div class="project-page-one__button">
                            <a class="img-popup" href="assets/images/work/tr15.jpg">
                                <img src="assets/images/icon/icon-zoom-1.png">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-6 col-md-6 filter-item">
                <div class="project-page-one__single">
                    <div class="project-page-one__img">
                        <img src="assets/images/work/tr17.jpg">
                        <div class="project-page-one__button">
                            <a class="img-popup" href="assets/images/work/tr17.jpg">
                                <img src="assets/images/icon/icon-zoom-1.png">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-6 col-md-6 filter-item">
                <div class="project-page-one__single">
                    <div class="project-page-one__img">
                        <img src="assets/images/work/tr16.jpg">
                        <div class="project-page-one__button">
                            <a class="img-popup" href="assets/images/work/tr16.jpg">
                                <img src="assets/images/icon/icon-zoom-1.png">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-6 col-md-6 filter-item">
                <div class="project-page-one__single">
                    <div class="project-page-one__img">
                        <img src="assets/images/work/tr18.jpg">
                        <div class="project-page-one__button">
                            <a class="img-popup" href="assets/images/work/tr18.jpg">
                                <img src="assets/images/icon/icon-zoom-1.png">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-6 col-md-6 filter-item">
                <div class="project-page-one__single">
                    <div class="project-page-one__img">
                        <img src="assets/images/work/tr20.jpg">
                        <div class="project-page-one__button">
                            <a class="img-popup" href="assets/images/work/tr20.jpg">
                                <img src="assets/images/icon/icon-zoom-1.png">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-6 col-md-6 filter-item">
                <div class="project-page-one__single">
                    <div class="project-page-one__img">
                        <img src="assets/images/work/tr19.jpg">
                        <div class="project-page-one__button">
                            <a class="img-popup" href="assets/images/work/tr19.jpg">
                                <img src="assets/images/icon/icon-zoom-1.png">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
             <div class="col-xl-3 col-lg-6 col-md-6 filter-item">
                <div class="project-page-one__single">
                    <div class="project-page-one__img">
                        <img src="assets/images/work/tr22.jpg">
                        <div class="project-page-one__button">
                            <a class="img-popup" href="assets/images/work/tr22.jpg">
                                <img src="assets/images/icon/icon-zoom-1.png">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-6 col-md-6 filter-item">
                <div class="project-page-one__single">
                    <div class="project-page-one__img">
                        <img src="assets/images/work/tr21.jpg">
                        <div class="project-page-one__button">
                            <a class="img-popup" href="assets/images/work/tr21.jpg">
                                <img src="assets/images/icon/icon-zoom-1.png">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-6 col-md-6 filter-item">
                <div class="project-page-one__single">
                    <div class="project-page-one__img">
                        <img src="assets/images/work/tr23.jpg">
                        <div class="project-page-one__button">
                            <a class="img-popup" href="assets/images/work/tr23.jpg">
                                <img src="assets/images/icon/icon-zoom-1.png">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
           <!--  <div class="col-xl-4 col-lg-6 col-md-6 filter-item">
                <div class="project-page-one__single">
                    <div class="project-page-one__img">
                        <img src="assets/images/work/basement1.jpg">
                        <div class="project-page-one__button">
                            <a class="img-popup" href="assets/images/work/basement1.jpg">
                                <img src="assets/images/icon/icon-zoom-1.png">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-lg-6 col-md-6 filter-item">
                <div class="project-page-one__single">
                    <div class="project-page-one__img">
                        <img src="assets/images/work/capillary.jpg">
                        <div class="project-page-one__button">
                            <a class="img-popup" href="assets/images/work/capillary.jpg">
                                <img src="assets/images/icon/icon-zoom-1.png">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-lg-6 col-md-6 filter-item">
                <div class="project-page-one__single">
                    <div class="project-page-one__img">
                        <img src="assets/images/work/exjoints.jpg">
                        <div class="project-page-one__button">
                            <a class="img-popup" href="assets/images/work/exjoints.jpg">
                                <img src="assets/images/icon/icon-zoom-1.png">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-lg-6 col-md-6 filter-item">
                <div class="project-page-one__single">
                    <div class="project-page-one__img">
                        <img src="assets/images/work/exterior.jpg">
                        <div class="project-page-one__button">
                            <a class="img-popup" href="assets/images/work/exterior.jpg">
                                <img src="assets/images/icon/icon-zoom-1.png">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-lg-6 col-md-6 filter-item">
                <div class="project-page-one__single">
                    <div class="project-page-one__img">
                        <img src="assets/images/work/terracewater.jpg">
                        <div class="project-page-one__button">
                            <a class="img-popup" href="assets/images/work/terracewater.jpg">
                                <img src="assets/images/icon/icon-zoom-1.png">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-lg-6 col-md-6 filter-item">
                <div class="project-page-one__single">
                    <div class="project-page-one__img">
                        <img src="assets/images/work/protective.jpg">
                        <div class="project-page-one__button">
                            <a class="img-popup" href="assets/images/work/protective.jpg">
                                <img src="assets/images/icon/icon-zoom-1.png">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-lg-6 col-md-6 filter-item">
                <div class="project-page-one__single">
                    <div class="project-page-one__img">
                        <img src="assets/images/work/injection.jpg">
                        <div class="project-page-one__button">
                            <a class="img-popup" href="assets/images/work/injection.jpg">
                                <img src="assets/images/icon/icon-zoom-1.png">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-lg-6 col-md-6 filter-item">
                <div class="project-page-one__single">
                    <div class="project-page-one__img">
                        <img src="assets/images/work/pool1.jpg">
                        <div class="project-page-one__button">
                            <a class="img-popup" href="assets/images/work/pool1.jpg">
                                <img src="assets/images/icon/icon-zoom-1.png">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-lg-6 col-md-6 filter-item">
                <div class="project-page-one__single">
                    <div class="project-page-one__img">
                        <img src="assets/images/work/material.jpg">
                        <div class="project-page-one__button">
                            <a class="img-popup" href="assets/images/work/material.jpg">
                                <img src="assets/images/icon/icon-zoom-1.png">
                            </a>
                        </div>
                    </div>
                </div>
            </div> -->
            
        </div>
    </div>
</section>
<!--Project Page One End-->


<!--Site Footer Start-->
<footer class="site-footer">
    <div class="site-footer__shape-1 float-bob-x">
        <img src="assets/images/shapes/site-footer-shape-1.png">
    </div>
    <div class="site-footer__top">
        <div class="container">
            <div class="site-footer__inner">
                <div class="site-footer__contact-info">
                    <ul class="site-footer__contact-points list-unstyled">
                        <li>
                            <div class="icon">
                                <span class="icon-location"></span>
                            </div>
                            <div class="content">
                                <h4>Address :</h4>
                                <p>E-8/67, Basantkunj, Shahpura, Bhopal-462039</p>
                            </div>
                        </li>
                        <li>
                            <div class="icon">
                                <span class="icon-email"></span>
                            </div>
                            <div class="content">
                                <h4>Email us :</h4>
                                <a href="mailto:rkwaterproofingandcompanybpl@gmail.com">rkwaterproofingandcompanybpl@gmail.com</a>
                            </div>
                        </li>
                        <li>
                            <div class="icon">
                                <span class="icon-telephone"></span>
                            </div>
                            <div class="content">
                                <h4>Call us on :</h4>
                                <a href="tel:+91 9669967206">+91 9669967206</a>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="site-footer__middle">
        <div class="container">
            <div class="row">
                <div class="col-xl-4 col-lg-6 col-md-6 wow fadeInUp" data-wow-delay="100ms">
                    <div class=" footer-widget__column footer-widget__img-box">
                        <div class="footer-widget__img">
                            <img src="assets/images/resources/footer-widget-img-1.png">
                        </div>
                    </div>
                </div>
                <div class="col-xl-2 col-lg-6 col-md-6 wow fadeInUp" data-wow-delay="200ms">
                    <div class="footer-widget__column footer-widget__useful-links">
                        <div class="footer-widget__title-box">
                            <h3 class="footer-widget__title">Quick Links</h3>
                        </div>
                        <ul class="footer-widget__useful-links-list list-unstyled">
                            <li><a href="index.php">Home </a></li>
                            <li><a href="about.php">About Us</a></li>
                            <li><a href="services.php">Services</a></li>
                            <li><a href="work.php">Our Work</a></li>
                            <li><a href="gallery.php">Gallery</a></li>
                            <li><a href="contact.php">Contact Us</a></li>
                        </ul>
                    </div>
                    <div class="site-footer__social">
                       <a href="https://www.facebook.com/profile.php?id=100090751406407"><i class="fab fa-facebook-f"></i></a>
                        <a href="#"><i class="fab fa-google-plus-g"></i></a>
                        <a href="https://www.instagram.com/rkwaterproofingandcompany/"><i class="fab fa-instagram"></i></a> 
                        <a href="https://www.linkedin.com/in/rk-waterproofing-and-company-00262b272/"><i class="fab fa-linkedin-in"></i></a>                  
                    </div>
                </div>
                <div class="col-xl-3 col-lg-6 col-md-6 wow fadeInUp" data-wow-delay="300ms">
                    <div class="footer-widget__column footer-widget__services">
                        <div class="footer-widget__title-box">
                            <h3 class="footer-widget__title">Work we do</h3>
                        </div>
                        <ul class="footer-widget__useful-links-list list-unstyled">
                            <li><a href="work.php">Terrace Water Proofing</a></li>
                            <li><a href="work.php">Basement Water Proofing</a></li>
                            <li><a href="work.php">Terrace Garden System</a></li>
                            <li><a href="work.php">Sunken Water Proofing</a></li>
                            <li><a href="work.php">Water Tank Water Proofing</a></li>
                            <li><a href="work.php">Swimming Pool Water Proofing</a></li>
                            <li><a href="work.php">Injection Grouting</a></li>
                            <li><a href="work.php">Expansion Joint Work</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-6 col-md-6 wow fadeInUp" data-wow-delay="400ms">
                    <div class="footer-widget__column footer-widget__services">
                        <div class="footer-widget__title-box">
                            <h3 class="footer-widget__title">Work we do</h3>
                        </div>
                        <ul class="footer-widget__useful-links-list list-unstyled">
                            
                            <li><a href="work.php"> Waterproofing Work</a></li>
                            <li><a href="work.php">Painting Work</a></li>
                          	<li><a href="work.php">Heat Insulating Coating</a></li>
                            <li><a href="work.php">Protective Coating</a></li>
                            <li><a href="work.php">Construction Chemicals</a></li>
                            <li><a href="work.php">Capillary Waterproofing</a></li>
                            <li><a href="work.php">Interior & Exterior Wall Treatment</a></li>
                            <li><a href="work.php">Old & New Building Joint Works</a></li>
                        </ul>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
    <div class="site-footer__bottom">
        <div class="container">
            <div class="row">
                <div class="col-xl-12">
                    <div class="site-footer__bottom-inner">
                        <p class="site-footer__bottom-text">Copyright © 2024  <a href="#">R.K. Waterproofing and Company</a>. All right reserved | Designed & Developed by: <a href="https://ginfosoft.com/" target="_blank">G-INFOSOFT TECHNOLOGIES</a></p>
                        <!-- <div class="site-footer__bottom-text-two">
                            <a href="#!">Purchase Now</a>
                        </div> -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<!--Site Footer End-->


</div><!-- /.page-wrapper -->


<div class="mobile-nav__wrapper">
    <div class="mobile-nav__overlay mobile-nav__toggler"></div>
    <!-- /.mobile-nav__overlay -->
    <div class="mobile-nav__content">
        <span class="mobile-nav__close mobile-nav__toggler"><i class="fa fa-times"></i></span>

        <div class="logo-box">
            <a href="index.html" aria-label="logo image"><img src="assets/images/resources/logo-1.png" width="200"
                    /></a>
        </div>
        <!-- /.logo-box -->
        <div class="mobile-nav__container"></div>
        <!-- /.mobile-nav__container -->

        <ul class="mobile-nav__contact list-unstyled">
            <li>
                <i class="fa fa-envelope"></i>
                <a href="mailto:rkwaterproofingandcompanybpl@gmail.com">rkwaterproofingandcompanybpl@gmail.com</a>
            </li>
            <li>
                <i class="fa fa-phone-alt"></i>
                <a href="tel:666-888-0000">+91 9669967206</a>
            </li>
        </ul><!-- /.mobile-nav__contact -->
        <div class="mobile-nav__top">
            <div class="mobile-nav__social">
                <a href="#" class="fab fa-twitter"></a>
                <a href="#" class="fab fa-facebook-square"></a>
                <a href="#" class="fab fa-instagram"></a>
            </div><!-- /.mobile-nav__social -->
        </div><!-- /.mobile-nav__top -->



    </div>
    <!-- /.mobile-nav__content -->
</div>
<!-- /.mobile-nav__wrapper -->

    

<a href="#" data-target="html" class="scroll-to-target scroll-to-top"><i class="fa fa-angle-up"></i></a>


<script src="assets/vendors/jquery/jquery-3.6.0.min.js"></script>
<script src="assets/vendors/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/vendors/jarallax/jarallax.min.js"></script>
<script src="assets/vendors/jquery-ajaxchimp/jquery.ajaxchimp.min.js"></script>
<script src="assets/vendors/jquery-appear/jquery.appear.min.js"></script>
<script src="assets/vendors/jquery-circle-progress/jquery.circle-progress.min.js"></script>
<script src="assets/vendors/jquery-magnific-popup/jquery.magnific-popup.min.js"></script>
<script src="assets/vendors/jquery-validate/jquery.validate.min.js"></script>
<script src="assets/vendors/nouislider/nouislider.min.js"></script>
<script src="assets/vendors/odometer/odometer.min.js"></script>
<script src="assets/vendors/swiper/swiper.min.js"></script>
<script src="assets/vendors/tiny-slider/tiny-slider.min.js"></script>
<script src="assets/vendors/wnumb/wNumb.min.js"></script>
<script src="assets/vendors/wow/wow.js"></script>
<script src="assets/vendors/isotope/isotope.js"></script>
<script src="assets/vendors/countdown/countdown.min.js"></script>
<script src="assets/vendors/owl-carousel/owl.carousel.min.js"></script>
<script src="assets/vendors/bxslider/jquery.bxslider.min.js"></script>
<script src="assets/vendors/bootstrap-select/js/bootstrap-select.min.js"></script>
<script src="assets/vendors/vegas/vegas.min.js"></script>
<script src="assets/vendors/jquery-ui/jquery-ui.js"></script>
<script src="assets/vendors/timepicker/timePicker.js"></script>
<script src="assets/vendors/circleType/jquery.circleType.js"></script>
<script src="assets/vendors/circleType/jquery.lettering.min.js"></script>
<script src="assets/vendors/sidebar-content/jquery-sidebar-content.js"></script>


<script src="assets/vendors/tweenmax/TweenMax.min.js"></script>
<!-- Template js -->
<script src="assets/js/endreox.js"></script>

</body>
</html>