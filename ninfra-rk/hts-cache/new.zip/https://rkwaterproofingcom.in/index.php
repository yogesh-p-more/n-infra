<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>R.K. Waterproofing and Company</title>
<link rel="icon" type="image/png" sizes="32x32" href="assets/images/favicons/favicon-32x32.png" />
<meta name="description" content="R.K. Waterproofing and Company" />
<link rel="preconnect" href="https://fonts.googleapis.com/">
<link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
<link
    href="https://fonts.googleapis.com/css2?family=Barlow:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&amp;display=swap"
    rel="stylesheet">
<link
    href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&amp;display=swap"
    rel="stylesheet">
<link
    href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&amp;display=swap"
    rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Yantramanav:wght@100;300;400;500;700;900&amp;display=swap"
    rel="stylesheet">

<link rel="stylesheet" href="assets/vendors/bootstrap/css/bootstrap.min.css" />
<link rel="stylesheet" href="assets/vendors/animate/animate.min.css" />
<link rel="stylesheet" href="assets/vendors/animate/custom-animate.css" />
<link rel="stylesheet" href="assets/vendors/fontawesome/css/all.min.css" />
<link rel="stylesheet" href="assets/vendors/jarallax/jarallax.css" />
<link rel="stylesheet" href="assets/vendors/jquery-magnific-popup/jquery.magnific-popup.css" />
<link rel="stylesheet" href="assets/vendors/nouislider/nouislider.min.css" />
<link rel="stylesheet" href="assets/vendors/nouislider/nouislider.pips.css" />
<link rel="stylesheet" href="assets/vendors/odometer/odometer.min.css" />
<link rel="stylesheet" href="assets/vendors/swiper/swiper.min.css" />
<link rel="stylesheet" href="assets/vendors/endreox-icons/style.css">
<link rel="stylesheet" href="assets/vendors/tiny-slider/tiny-slider.min.css" />
<link rel="stylesheet" href="assets/vendors/reey-font/stylesheet.css" />
<link rel="stylesheet" href="assets/vendors/owl-carousel/owl.carousel.min.css" />
<link rel="stylesheet" href="assets/vendors/owl-carousel/owl.theme.default.min.css" />
<link rel="stylesheet" href="assets/vendors/bxslider/jquery.bxslider.css" />
<link rel="stylesheet" href="assets/vendors/bootstrap-select/css/bootstrap-select.min.css" />
<link rel="stylesheet" href="assets/vendors/vegas/vegas.min.css" />
<link rel="stylesheet" href="assets/vendors/jquery-ui/jquery-ui.css" />
<link rel="stylesheet" href="assets/vendors/timepicker/timePicker.css" />
<link rel="stylesheet" href="assets/vendors/free-hand-font/stylesheet.css" />

<!-- template styles -->
<link rel="stylesheet" href="assets/css/endreox.css" />
<link rel="stylesheet" href="assets/css/endreox-responsive.css" />
</head>

<body class="custom-cursor">

    <div class="custom-cursor__cursor"></div>
    <div class="custom-cursor__cursor-two"></div>

<div class="page-wrapper">

<header class="main-header-three">
    <div class="main-header-three__top">
        <div class="container">
            <div class="main-header-three__top-inner">
                <div class="main-header-three__top-left">
                    <p class="main-header-three__top-left-text">All Kind of Waterproofing Treatment. <a href="enquiry.php"> Get A Quote Today!</a></p>
                </div>
                <div>
                    <a href="mailto:rkwaterproofingandcompanybpl@gmail.com"><i class="icon-email"> rkwaterproofingandcompanybpl@gmail.com</i></a>
                </div>
              	<div>
                    <a href="tel:+91 7554134061"><i class="icon-telephone"> <strong>+91 7554134061</strong></i></a>
                </div>
                <div class="main-header-three__top-social">
                    <a href="https://www.facebook.com/profile.php?id=100090751406407"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-google-plus-g"></i></a>
                    <a href="https://www.instagram.com/rkwaterproofingandcompany/"><i class="fab fa-instagram"></i></a>
                    <a href="https://www.linkedin.com/in/rk-waterproofing-and-company-00262b272/"><i class="fab fa-linkedin-in"></i></a>
                </div>
            </div>
        </div>
    </div>
    <div class="main-header-three__middle">
        <div class="container">
            <div class="main-header-three__middle-inner">
                <div class="main-header-three__logo">
                    <a href="index.php"><img src="assets/images/resources/logo-2.png" alt="" width="350"></a>
                </div>
                <div class="main-header-three__contact-box">
                    <ul class="list-unstyled main-header-three__contact-list">
                        <li>
                            <div class="icon">
                                <a href="http://wa.me/919669967206" target="_blank"><span class="fab fa-whatsapp text-green"></span></a>
                            </div>
                        </li>
                        <li>
                            <div class="icon">
                                <span class="icon-telephone"></span>
                            </div>
                            <div class="content">
                                <h5>Call Us</h5>
                                <p><a href="tel:+91 9669967206">+91 9669967206</a></p>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <nav class="main-menu main-menu-three">
        <div class="main-menu-three__wrapper">
            <div class="container">
                <div class="main-menu-three__wrapper-inner">
                    <div class="main-menu-three__left">
                        <div class="main-menu-three__main-menu-box">
                            <a href="#" class="mobile-nav__toggler"><i class="fa fa-bars"></i></a>
                            <ul class="main-menu__list">
                                <li><a href="index.php">Home </a></li>
                                <li><a href="about.php">About Us</a></li>
                                <li><a href="services.php">Services</a></li>
                                <li class="dropdown">
                                    <a href="work.php">Our Work</a>
                                    <ul>
                                        <li><a href="work.php">Terrace Water Proofing</a></li>
                                        <li><a href="work.php">Basement Water Proofing</a></li>
                                        <li><a href="work.php">Terrace Garden System</a></li>
                                        <li><a href="work.php">Sunken Water Proofing</a></li>
                                        <li><a href="work.php">Water Tank Water Proofing</a></li>
                                        <li><a href="work.php">Swimming Pool Water Proofing</a></li>
                                        <li><a href="work.php">Injection Grouting</a></li>
                                        <li><a href="work.php">Expansion Joint Work</a></li>
                                        <li><a href="work.php"> Waterproofing Material</a></li>
                                        <li><a href="work.php">Construction Chemicals</a></li>
                                        <li><a href="work.php">Painting Work</a></li>
                                        <li><a href="work.php">Protective Coating</a></li>
                                        <li><a href="work.php">Heat Insulating Coating</a></li>
                                        <li><a href="work.php">Capillary Waterproofing</a></li>
                                        <li><a href="work.php">Interior & Exterior Wall Treatment</a></li>
                                        <li><a href="work.php">Old & New Building Joint Works</a></li>

                                    </ul>
                                </li>
                                <li><a href="gallery.php">Gallery</a></li>
                                <li><a href="contact.php">Contact Us</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="main-menu-three__right">
                        <div class="main-menu-three__btn-box">
                            <a href="enquiry.php" class="thm-btn main-menu-three__btn">Enquiry</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </nav>
</header>

<div class="stricky-header stricked-menu main-menu main-menu-three">
    <div class="sticky-header__content"></div><!-- /.sticky-header__content -->
</div><!-- /.stricky-header -->

<!--Main Slider Two Start-->
<section class="main-slider-two clearfix">
    <div class="swiper-container thm-swiper__slider" data-swiper-options='{"slidesPerView": 1, "loop": true,
        "effect": "fade",
        "pagination": {
        "el": "#main-slider-pagination",
        "type": "bullets",
        "clickable": true
        },
        "navigation": {
        "nextEl": "#main-slider__swiper-button-next",
        "prevEl": "#main-slider__swiper-button-prev"
        },
        "autoplay": {
        "delay": 5000
        }}'>
        <div class="swiper-wrapper">

            <div class="swiper-slide">
                <div class="main-slider__img">
                    <img src="assets/images/resources/main-slider-2-1.png" class="float-bob-y">
                    <div class="main-slider__service-start">
                        <img src="assets/images/shapes/warranty.png">
                    </div>
                </div>
                <div class="main-slider-two__shape-1">
                    <img src="assets/images/shapes/main-slider-two-shape-1.png">
                </div>
                <div class="container">
                    <div class="row">
                        <div class="col-xl-7">
                            <div class="main-slider-two__content">
                                <h5 class="main-slider-two__sub-title">R.K. Waterproofing & Company</h5>
                                <h2 class="main-slider-two__title">Highly Qualified and <br>Skilled Expertise</h2>
                                <!-- <h4 class="main-slider-two__text-1">Same day service Guaranteed Or It’s Free!
                                </h4> -->
                                <h5 class="main-slider-two__text-2">This trust is based upon our quality image and our reputation for consistently<br> delivering high-quality products. We offer efficient services along with complete<br> technical assistance and valuable suggestions.</h5>
                                <div class="main-slider-two__btn-box">
                                    <a href="tel:+919669967206" class="thm-btn main-slider-two__btn">Call us now</a>
                                </div>
                                <div class="main-slider-two__shape-2"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="swiper-slide">
                <div class="main-slider__img">
                    <img src="assets/images/resources/main-slider-2-2.png" class="float-bob-y">
                    <div class="main-slider__service-start">
                        <img src="assets/images/shapes/warranty.png">
                    </div>
                </div>
                <div class="main-slider-two__shape-1">
                    <img src="assets/images/shapes/main-slider-two-shape-1.png">
                </div>
                <div class="container">
                    <div class="row">
                        <div class="col-xl-7">
                            <div class="main-slider-two__content">
                                <h5 class="main-slider-two__sub-title">R.K. Waterproofing & Company</h5>
                                <h2 class="main-slider-two__title">Expert Waterproofing <br> Solutions</h2>
                                <!-- <h4 class="main-slider-two__text-1">Same day service Guaranteed Or It’s Free!
                                </h4> -->
                                <h5 class="main-slider-two__text-2">We just not simply start the work and finish, we study deeply with the root cause of problem area and come with proper long term solution and work accordingly which result in 100 % customer satisfaction achievement..</h5>
                                <div class="main-slider-two__btn-box">
                                    <a href="contact.php" class="thm-btn main-slider-two__btn">Call us now</a>
                                </div>
                                <div class="main-slider-two__shape-2"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="swiper-slide">
                <div class="main-slider__img">
                    <img src="assets/images/resources/main-slider-2-3.png" class="float-bob-y">
                    <div class="main-slider__service-start">
                        <img src="assets/images/shapes/warranty.png">
                    </div>
                </div>
                <div class="main-slider-two__shape-1">
                    <img src="assets/images/shapes/main-slider-two-shape-1.png">
                </div>
                <div class="container">
                    <div class="row">
                        <div class="col-xl-7">
                            <div class="main-slider-two__content">
                                <h5 class="main-slider-two__sub-title">R.K. Waterproofing & Company</h5>
                                <h2 class="main-slider-two__title">Wet or Moldy <br>Basement</h2>
                                <!-- <h4 class="main-slider-two__text-1">Same day service Guaranteed Or It’s Free!</h4> -->
                                <h5 class="main-slider-two__text-2">Our trained waterproofing contractors spread across the country and offering complete assistance and valuable suggestions as per requirement. Our company follows the latest trends in equipment and process.</h5>
                                <div class="main-slider-two__btn-box">
                                    <a href="contact.php" class="thm-btn main-slider-two__btn">Call us now</a>
                                </div>
                                <div class="main-slider-two__shape-2"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- New slider -->

            <div class="swiper-slide">
                <div class="main-slider__img">
                    <img src="assets/images/resources/main-slider-2-4.png" class="float-bob-y">
                    <div class="main-slider__service-start">
                        <img src="assets/images/shapes/warranty.png">
                    </div>
                </div>
                <div class="main-slider-two__shape-1">
                    <img src="assets/images/shapes/main-slider-two-shape-1.png">
                </div>
                <div class="container">
                    <div class="row">
                        <div class="col-xl-7">
                            <div class="main-slider-two__content">
                                <h5 class="main-slider-two__sub-title">R.K. Waterproofing & Company</h5>
                                <h2 class="main-slider-two__title">Terrace Waterproofing</h2>
                                <!-- <h4 class="main-slider-two__text-1">Same day service Guaranteed Or It’s Free!
                                </h4> -->
                                <h5 class="main-slider-two__text-2">Even though we deal with all most all the water proofing chemicals & all the <br>methodology after analyzed the floor type and customer <br>requirement we suggest the suitable methodology.</h5>
                                <div class="main-slider-two__btn-box">
                                    <a href="tel:+919669967206" class="thm-btn main-slider-two__btn">Call us now</a>
                                </div>
                                <div class="main-slider-two__shape-2"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="swiper-slide">
                <div class="main-slider__img">
                    <img src="assets/images/resources/main-slider-2-5.png" class="float-bob-y">
                    <div class="main-slider__service-start">
                        <img src="assets/images/shapes/warranty.png">
                    </div>
                </div>
                <div class="main-slider-two__shape-1">
                    <img src="assets/images/shapes/main-slider-two-shape-1.png">
                </div>
                <div class="container">
                    <div class="row">
                        <div class="col-xl-7">
                            <div class="main-slider-two__content">
                                <h5 class="main-slider-two__sub-title">R.K. Waterproofing & Company</h5>
                                <h2 class="main-slider-two__title">100% Permanent <br>Terrace Waterproofing</h2>
                                <!-- <h4 class="main-slider-two__text-1">Same day service Guaranteed Or It’s Free!
                                </h4> -->
                                <h5 class="main-slider-two__text-2">Please do call us +919669967206 for choosing suitable product for your<br> terrace waterproofing requirements. our expert will give best solution and<br> explain the benefits of terrace waterproofing solutions.</h5>
                                <div class="main-slider-two__btn-box">
                                    <a href="tel:+919669967206" class="thm-btn main-slider-two__btn">Call us now</a>
                                </div>
                                <div class="main-slider-two__shape-2"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="swiper-slide">
                <div class="main-slider__img">
                    <img src="assets/images/resources/main-slider-2-6.png" class="float-bob-y">
                    <div class="main-slider__service-start">
                        <img src="assets/images/shapes/warranty.png">
                    </div>
                </div>
                <div class="main-slider-two__shape-1">
                    <img src="assets/images/shapes/main-slider-two-shape-1.png">
                </div>
                <div class="container">
                    <div class="row">
                        <div class="col-xl-7">
                            <div class="main-slider-two__content">
                                <h5 class="main-slider-two__sub-title">R.K. Waterproofing & Company</h5>
                                <h2 class="main-slider-two__title">Terrace Waterproofing<br>Excellent Waterproofing Capability</h2>
                                <!-- <h4 class="main-slider-two__text-1">Same day service Guaranteed Or It’s Free!
                                </h4> -->
                                <h5 class="main-slider-two__text-2">Though the different surfaces require different application methods, the <br>basic steps are surface preparation, crack filling, application of the<br> primary coating, then the secondary coating, and the final finish.</h5>
                                <div class="main-slider-two__btn-box">
                                    <a href="tel:+919669967206" class="thm-btn main-slider-two__btn">Call us now</a>
                                </div>
                                <div class="main-slider-two__shape-2"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <!-- If we need navigation buttons -->
        <div class="main-slider-two__nav">
            <div class="swiper-button-prev" id="main-slider__swiper-button-next">
                <i class="fa fa-arrow-left"></i>
            </div>
            <div class="swiper-button-next" id="main-slider__swiper-button-prev">
                <i class="fa fa-arrow-right"></i>
            </div>
        </div>


    </div>
</section>
<!--Main Slider Two End-->

<!--Experience And Rating Start-->
<section class="experience-and-rating">
    <div class="container">
        <div class="row">
            <div class="col-xl-6 col-lg-6">
                <div class="experience-and-rating__left">
                    <div class="experience-and-rating__experience">
                        <div class="experience-and-rating__experience-year">
                            <h2>11</h2>
                            <h5>years of experience</h5>
                        </div>
                        <div class="experience-and-rating__experience-text-box">
                            <p>With the latest technology available in the market & our own invented methods.</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-6 col-lg-6">
                <div class="experience-and-rating__right">
                    <div class="experience-and-rating__rating-box">
                        <div class="experience-and-rating__rating-icon">
                            <span class="icon-review"></span>
                        </div>
                        <p class="experience-and-rating__rating-text"> We have successfully completed our projects in Bhopal with 100% customer satisfaction.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--Experience And Rating End-->

<!--About Two Start-->
<section class="about-two">
    <div class="container">
        <div class="row">
            <div class="col-xl-4 col-lg-4">
                <div class="about-two__left">
                    <div class="about-two__img-box wow slideInLeft" data-wow-delay="100ms"
                        data-wow-duration="2500ms">
                        <div class="about-two__img">
                            <img src="assets/images/waterproofing-protections.jpg">
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-8 col-lg-8">
                <div class="about-two__right">
                    <div class="section-title text-left">
                        <span class="section-title__tagline">About Us</span>
                        <h2 class="section-title__title">Complete Construction Chemical & Waterproofing Solution</h2>
                    </div>
                    <p class="about-two__text-2">We provide waterproofing solutions for structures which include terraces, parapet walls, ducts, concealed leak lines, sidewalls, balconies, bathrooms, kitchen sinks, water tanks, swimming pools and basements and ensure expert systems to the repair and rehabilitation industry which makes us the best waterproofing contractors and consultants in Bhopal.</p>
                    <div class="about-two__points-box">
                        <ul class="about-two__points list-unstyled">
                            <li>
                                <div class="icon">
                                    <span class="icon-comment"></span>
                                </div>
                                <div class="text">
                                    <p>Unique Products With High Competency</p>
                                </div>
                            </li>
                            <li>
                                <div class="icon">
                                    <span class="icon-comment"></span>
                                </div>
                                <div class="text">
                                    <p>100% Satisfaction Guarantee</p>
                                </div>
                            </li>
                            <li>
                                <div class="icon">
                                    <span class="icon-comment"></span>
                                </div>
                                <div class="text">
                                    <p>Quality Control System</p>
                                </div>
                            </li>
                        </ul>
                        <ul class="about-two__points about-two__points-2 list-unstyled">
                            <li>
                                <div class="icon">
                                    <span class="icon-comment"></span>
                                </div>
                                <div class="text">
                                    <p>Environment Friendly</p>
                                </div>
                            </li>
                            <li>
                                <div class="icon">
                                    <span class="icon-comment"></span>
                                </div>
                                <div class="text">
                                    <p>Special Focus On Innovation & Research</p>
                                </div>
                            </li>
                            <li>
                                <div class="icon">
                                    <span class="icon-comment"></span>
                                </div>
                                <div class="text">
                                    <p>Qualified Professionals</p>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--About Two End-->

<!--Services Three Start-->
<section class="services-three" style="background-color: #ECF1F5;">
    <div class="container">
        <div class="services-three__top">
            <div class="row">
                <div class="col-xl-4 col-lg-4">
                    <div class="services-three__left">
                        <div class="section-title text-left">
                            <span class="section-title__tagline">Our services</span>
                            <h2 class="section-title__title">What We Do</h2>
                        </div>
                    </div>
                </div>
                <div class="col-xl-8 col-lg-8">
                    <div class="services-three__right">
                        <p class="services-three__text">With skilled and qualified professionals at work, we are experts at tackling the most challenging waterproofing challenges and this confidence in our work inspires us to continue growing in every department.</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="services-three__middle">
            <div class="services-three__carousel owl-carousel owl-theme thm-owl__carousel" data-owl-options='{
                "loop": true,
                "autoplay": true,
                "margin": 30,
                "nav": true,
                "dots": false,
                "smartSpeed": 500,
                "autoplayTimeout": 10000,
                "navText": ["<span class=\"fa fa-angle-left\"></span>","<span class=\"fa fa-angle-right\"></span>"],
                "responsive": {
                    "0": {
                        "items": 1
                    },
                    "768": {
                        "items": 2
                    },
                    "992": {
                        "items": 3
                    },
                    "1200": {
                        "items": 4
                    }
                }
            }'>
                <!--Services Three single Start-->
                <div class="item">
                    <div class="services-three__single">
                        <div class="services-three__img-box">
                            <div class="services-three__img">
                                <img src="assets/images/services/liquid-membrane/liq1.jpg">
                            </div>
                        </div>
                        <div class="services-three__content-box">
                            <h3 class="services-three__title"><a href="services.php">Liquid Membrane<br> System</a></h3>
                            <div class="services-three__read-more">
                                <a href="services.php">Read more <span>+</span></a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--Services Three single End-->

                <!--Services Three single Start-->
                <div class="item">
                    <div class="services-three__single">
                        <div class="services-three__img-box">
                            <div class="services-three__img">
                                <img src="assets/images/services/app1.jpg">
                            </div>
                        </div>
                        <div class="services-three__content-box">
                            <h3 class="services-three__title"><a href="services.php">APP Membrane<br> System</a></h3>
                            <div class="services-three__read-more">
                                <a href="services.php">Read more <span>+</span></a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--Services Three single End-->
                <!--Services Three single Start-->
                <div class="item">
                    <div class="services-three__single">
                        <div class="services-three__img-box">
                            <div class="services-three__img">
                                <img src="assets/images/services/cementatious-coating/cement3.jpg">
                            </div>
                        </div>
                        <div class="services-three__content-box">
                            <h3 class="services-three__title"><a href="services.php">Cementatious<br> Coating</a></h3>
                            <div class="services-three__read-more">
                                <a href="services.php">Read more <span>+</span></a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--Services Three single End-->
                <!--Services Three single Start-->
                <div class="item">
                    <div class="services-three__single">
                        <div class="services-three__img-box">
                            <div class="services-three__img">
                                <img src="assets/images/services/protective/protective1.jpg">
                            </div>
                        </div>
                        <div class="services-three__content-box">
                            <h3 class="services-three__title"><a href="services.php">Protective<br> Coating</a></h3>
                            <div class="services-three__read-more">
                                <a href="services.php">Read more <span>+</span></a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--Services Three single End-->
                <!--Services Three single Start-->
                <div class="item">
                    <div class="services-three__single">
                        <div class="services-three__img-box">
                            <div class="services-three__img">
                                <img src="assets/images/services/decorative/dec2.jpg">
                            </div>
                        </div>
                        <div class="services-three__content-box">
                            <h3 class="services-three__title"><a href="services.php">Decorative<br> Coating</a></h3>
                            <div class="services-three__read-more">
                                <a href="services.php">Read more <span>+</span></a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--Services Three single End-->
                <!--Services Three single Start-->
                <div class="item">
                    <div class="services-three__single">
                        <div class="services-three__img-box">
                            <div class="services-three__img">
                                <img src="assets/images/services/expansion-joints/exj3.jpg">
                            </div>
                        </div>
                        <div class="services-three__content-box">
                            <h3 class="services-three__title"><a href="services.php">Expansion Joint<br> Treatment</a></h3>
                            <div class="services-three__read-more">
                                <a href="services.php">Read more <span>+</span></a>
                            </div>
                        </div>
                    </div>
                </div>
                <!--Services Three single End-->
            </div>
        </div>
        <div class="services-three__bottom">
            <div class="row">
                <div class="col-xl-4 col-lg-4 col-md-6">
                    <div class="additional-services__left">
                        <!-- <span class="section-title__tagline">Leaders in Construction and Water Proofing Chemicals</span> -->
                        <h3 class="additional-services__title">Our Work</h3>
                    </div>
                </div>
                
                <div class="col-xl-8 col-lg-8 col-md-6">
                    <div class="additional-services__single">
                        <p class="additional-services__text">We use the latest technology to prevent any sort of leakages for all the new and old constructions with the modern waterproofing methods.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--Services Three End-->

<!--Services Four Start-->
<section class="services-five" style="background-color:#ECF1F5;">
    <div class="services-one__bottom">
        <div class="services-one__carousel owl-carousel owl-theme thm-owl__carousel" data-owl-options='{
        "loop": true,
        "autoplay": true,
        "margin": 6,
        "nav": false,
        "dots": false,
        "smartSpeed": 500,
        "autoplayTimeout": 10000,
        "navText": ["<span class=\"icon-left-arrow\"></span>","<span class=\"icon-right-arrow\"></span>"],
        "responsive": {
            "0": {
                "items": 1
            },
            "768": {
                "items": 2
            },
            "992": {
                "items": 2
            },
            "1200": {
                "items": 3
            }
        }
        }'>
            <!--Services One Single Start-->
            <div class="item">
                <div class="services-one__single">
                    <div class="services-one__img-box">
                        <div class="services-one__img">
                            <img src="assets/images/work/terracewater.jpg">
                        </div>
                        <div class="services-one__content">
                            <h3 class="services-one__title"><a href="work.php">Terrace Water Proofing<i class="icon-right-arrow"></i></a></h3>
                        </div>
                        <!-- <div class="services-one__shape-1">
                            <img src="assets/images/shapes/services-one-shape-1.png">
                        </div> -->
                    </div>
                    <div class="services-one__shape-2"></div>
                </div>
            </div>
            <!--Services One Single End-->
            <!--Services One Single Start-->
            <div class="item">
                <div class="services-one__single">
                    <div class="services-one__img-box">
                        <div class="services-one__img">
                            <img src="assets/images/work/basement1.jpg">
                        </div>
                        <div class="services-one__content">
                            <h3 class="services-one__title"><a href="work.php">Basement Water Proofing<i class="icon-right-arrow"></i></a></h3>
                        </div>
                        <!-- <div class="services-one__shape-1">
                            <img src="assets/images/shapes/services-one-shape-1.png">
                        </div> -->
                    </div>
                    <div class="services-one__shape-2"></div>
                </div>
            </div>
            <!--Services One Single End-->
            <!--Services One Single Start-->
            <div class="item">
                <div class="services-one__single">
                    <div class="services-one__img-box">
                        <div class="services-one__img">
                            <img src="assets/images/work/garden.jpg">
                        </div>
                        <div class="services-one__content">
                            <h3 class="services-one__title"><a href="work.php">Terrace Garden System<i class="icon-right-arrow"></i></a></h3>
                        </div>
                        <!-- <div class="services-one__shape-1 services-one__shape-3">
                            <img src="assets/images/shapes/services-one-shape-1.png">
                        </div> -->
                    </div>
                    <div class="services-one__shape-2"></div>
                </div>
            </div>
            <!--Services One Single End-->

            <!--Services One Single Start-->
            <div class="item">
                <div class="services-one__single">
                    <div class="services-one__img-box">
                        <div class="services-one__img">
                            <img src="assets/images/work/sunken.jpg">
                        </div>
                        <div class="services-one__content">
                            <h3 class="services-one__title"><a href="work.php">Sunken Water Proofing<i class="icon-right-arrow"></i></a></h3>
                        </div>
                        <!-- <div class="services-one__shape-1">
                            <img src="assets/images/shapes/services-one-shape-1.png">
                        </div> -->
                    </div>
                    <div class="services-one__shape-2"></div>
                </div>
            </div>
            <!--Services One Single End-->
            <!--Services One Single Start-->
            <div class="item">
                <div class="services-one__single">
                    <div class="services-one__img-box">
                        <div class="services-one__img">
                            <img src="assets/images/work/watertank.jpg">
                        </div>
                        <div class="services-one__content">
                            <h3 class="services-one__title"><a href="work.php">Water Tank Water Proofing<i class="icon-right-arrow"></i></a></h3>
                        </div>
                        <!-- <div class="services-one__shape-1">
                            <img src="assets/images/shapes/services-one-shape-1.png">
                        </div> -->
                    </div>
                    <div class="services-one__shape-2"></div>
                </div>
            </div>
            <!--Services One Single End-->
            <!--Services One Single Start-->
            <div class="item">
                <div class="services-one__single">
                    <div class="services-one__img-box">
                        <div class="services-one__img">
                            <img src="assets/images/work/pool1.jpg">
                        </div>
                        <div class="services-one__content">
                            <h3 class="services-one__title"><a href="work.php">Swimming Pool Water Proofing<i class="icon-right-arrow"></i></a></h3>
                        </div>
                        <!-- <div class="services-one__shape-1 services-one__shape-3">
                            <img src="assets/images/shapes/services-one-shape-1.png">
                        </div> -->
                    </div>
                    <div class="services-one__shape-2"></div>
                </div>
            </div>
            <!--Services One Single End-->
        </div>
    </div>
</section>
<!--Services Four End-->

<!--Counter Two Start-->
<!-- <section class="counter-two">
    <div class="container">
        <div class="row">
            <div class="col-xl-4 col-lg-4">
                <div class="counter-one__left">
                    <div class="counter-one__year-box">
                        <p class="counter-one__year">PROJECTS IMPLEMENTED</p>
                        <h3 class="counter-one__year-title">Let Us Ensure Your <span>Building's Longevity.</span>
                        </h3>
                    </div>
                </div>
            </div>
            <div class="col-xl-8 col-lg-8">
                <div class="counter-one__right">
                    <ul class="counter-one__box list-unstyled">
                        <li class="counter-one__single">
                            <div class="counter-one__icon">
                                <span class="icon-home"></span>
                            </div>
                            <div class="counter-one__content-box">
                                <h3 class="odometer" data-count="450">00</h3><span
                                    class="counter-one__letter">+</span>
                                <p class="counter-one__text">Residential
                                    <br> Projects</p>
                            </div>
                        </li>
                        <li class="counter-one__single">
                            <div class="counter-one__icon">
                                <span class="icon-office-building"></span>
                            </div>
                            <div class="counter-one__content-box">
                                <h3 class="odometer" data-count="120">00</h3><span
                                    class="counter-one__letter">+</span>
                                <p class="counter-one__text">Commercial
                                    <br> Projects</p>
                            </div>
                        </li>
                        <li class="counter-one__single">
                            <div class="counter-one__icon">
                                <span class="icon-satisfaction"></span>
                            </div>
                            <div class="counter-one__content-box">
                                <h3 class="odometer" data-count="700">00</h3><span
                                    class="counter-one__letter">+</span>
                                <p class="counter-one__text">Customer
                                    <br> Satisfaction</p>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section> -->
<!--Counter Two End-->

<!--Gallery Start-->
<section class="project-three">
    <div class="container">
        <div class="section-title text-center">
            <span class="section-title__tagline">Our Gallery</span>
            <h2 class="section-title__title">Projects we have done yet</h2>
            <p class="text-white">We are constantly working to challenge the conventional ideas and notions of architecture, design, structural durability and materials. Completing the work in the estimated time within-budget as mentioned previously in the quotation.</p>
        </div>
        <div class="row filter-layout">
            
            <div class="col-xl-4 col-lg-6 col-md-6">
                <div class="project-one__single">
                    <div class="project-one__img">
                        <img src="assets/images/work/liq1.jpg">
                        <div class="project-one__button">
                            <a class="img-popup" href="assets/images/work/liq1.jpg">
                                <img src="assets/images/icon/icon-zoom-1.png">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-4 col-lg-6 col-md-6">
                <div class="project-one__single">
                    <div class="project-one__img">
                        <img src="assets/images/work/tr1.jpg">
                        <div class="project-one__button">
                            <a class="img-popup" href="assets/images/work/tr1.jpg">
                                <img src="assets/images/icon/icon-zoom-1.png">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-4 col-lg-6 col-md-6">
                <div class="project-one__single">
                    <div class="project-one__img">
                        <img src="assets/images/work/tr6.jpg">
                        <div class="project-one__button">
                            <a class="img-popup" href="assets/images/work/tr6.jpg">
                                <img src="assets/images/icon/icon-zoom-1.png">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-4 col-lg-6 col-md-6">
                <div class="project-one__single">
                    <div class="project-one__img">
                        <img src="assets/images/work/tr7.jpg">
                        <div class="project-one__button">
                            <a class="img-popup" href="assets/images/work/tr7.jpg">
                                <img src="assets/images/icon/icon-zoom-1.png">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-4 col-lg-6 col-md-6">
                <div class="project-one__single">
                    <div class="project-one__img">
                        <img src="assets/images/work/tr2.jpg">
                        <div class="project-one__button">
                            <a class="img-popup" href="assets/images/work/tr2.jpg">
                                <img src="assets/images/icon/icon-zoom-1.png">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-4 col-lg-6 col-md-6">
                <div class="project-one__single">
                    <div class="project-one__img">
                        <img src="assets/images/work/tr20.jpg">
                        <div class="project-one__button">
                            <a class="img-popup" href="assets/images/work/tr20.jpg">
                                <img src="assets/images/icon/icon-zoom-1.png">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--Gallery End-->

<!--Project Two Start-->
<!-- <section class="project-two">
    <div class="project-two__bg" style="background-image: url(assets/images/backgrounds/project-two-bg.jpg);">
    </div>
    <div class="container">
        <div class="row">
            <div class="col-xl-3">
                <div class="project-two__left">
                    <div class="services-three__left">
                        <div class="section-title text-left">
                            <span class="section-title__tagline">Our Work</span>
                            <h2 class="section-title__title">Our Recent
                                Projects</h2>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-9">
                <div class="project-two__right">
                    <div class="project-two__carousel owl-carousel owl-theme thm-owl__carousel"
                        data-owl-options='{
                        "loop": true,
                        "autoplay": true,
                        "margin": 30,
                        "nav": true,
                        "dots": false,
                        "smartSpeed": 500,
                        "autoplayTimeout": 10000,
                        "navText": ["<span class=\"fa fa-arrow-left\"></span>","<span class=\"fa fa-arrow-right\"></span>"],
                        "responsive": {
                            "0": {
                                "items": 1
                            },
                            "768": {
                                "items": 2
                            },
                            "992": {
                                "items": 3
                            },
                            "1200": {
                                "items": 3
                            }
                        }
                    }'>
                        
                        <div class="item">
                            <div class="project-two__single">
                                <div class="project-two__img">
                                    <img src="assets/images/project/project-2-1.jpg">
                                    <div class="project-two__content">
                                        <p class="project-two__sub-title">Loxis Project</p>
                                        <h4 class="project-two__title"><a href="project-details.html">Electrical
                                                Fixes</a></h4>
                                    </div>
                                    <div class="project-two__button">
                                        <a class="img-popup" href="assets/images/project/project-page-1-1.jpg">
                                            <img src="assets/images/icon/icon-zoom-1.png">
                                        </a>
                                        <a href="project-details.html">
                                            <img src="assets/images/icon/link-icon-1.png">
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="item">
                            <div class="project-two__single">
                                <div class="project-two__img">
                                    <img src="assets/images/project/project-2-2.jpg">
                                    <div class="project-two__content">
                                        <p class="project-two__sub-title">Loxis Project</p>
                                        <h4 class="project-two__title"><a href="project-details.html">Electrical
                                                Fixes</a></h4>
                                    </div>
                                    <div class="project-two__button">
                                        <a class="img-popup" href="assets/images/project/project-page-1-1.jpg">
                                            <img src="assets/images/icon/icon-zoom-1.png">
                                        </a>
                                        <a href="project-details.html">
                                            <img src="assets/images/icon/link-icon-1.png">
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="item">
                            <div class="project-two__single">
                                <div class="project-two__img">
                                    <img src="assets/images/project/project-2-3.jpg">
                                    <div class="project-two__content">
                                        <p class="project-two__sub-title">Loxis Project</p>
                                        <h4 class="project-two__title"><a href="project-details.html">Electrical
                                                Fixes</a></h4>
                                    </div>
                                    <div class="project-two__button">
                                        <a class="img-popup" href="assets/images/project/project-page-1-1.jpg">
                                            <img src="assets/images/icon/icon-zoom-1.png">
                                        </a>
                                        <a href="project-details.html">
                                            <img src="assets/images/icon/link-icon-1.png">
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="item">
                            <div class="project-two__single">
                                <div class="project-two__img">
                                    <img src="assets/images/project/project-2-1.jpg">
                                    <div class="project-two__content">
                                        <p class="project-two__sub-title">Loxis Project</p>
                                        <h4 class="project-two__title"><a href="project-details.html">Electrical
                                                Fixes</a></h4>
                                    </div>
                                    <div class="project-two__button">
                                        <a class="img-popup" href="assets/images/project/project-page-1-1.jpg">
                                            <img src="assets/images/icon/icon-zoom-1.png">
                                        </a>
                                        <a href="project-details.html">
                                            <img src="assets/images/icon/link-icon-1.png">
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="item">
                            <div class="project-two__single">
                                <div class="project-two__img">
                                    <img src="assets/images/project/project-2-2.jpg">
                                    <div class="project-two__content">
                                        <p class="project-two__sub-title">Loxis Project</p>
                                        <h4 class="project-two__title"><a href="project-details.html">Electrical
                                                Fixes</a></h4>
                                    </div>
                                    <div class="project-two__button">
                                        <a class="img-popup" href="assets/images/project/project-page-1-1.jpg">
                                            <img src="assets/images/icon/icon-zoom-1.png">
                                        </a>
                                        <a href="project-details.html">
                                            <img src="assets/images/icon/link-icon-1.png">
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="item">
                            <div class="project-two__single">
                                <div class="project-two__img">
                                    <img src="assets/images/project/project-2-3.jpg">
                                    <div class="project-two__content">
                                        <p class="project-two__sub-title">Loxis Project</p>
                                        <h4 class="project-two__title"><a href="project-details.html">Electrical
                                                Fixes</a></h4>
                                    </div>
                                    <div class="project-two__button">
                                        <a class="img-popup" href="assets/images/project/project-page-1-1.jpg">
                                            <img src="assets/images/icon/icon-zoom-1.png">
                                        </a>
                                        <a href="project-details.html">
                                            <img src="assets/images/icon/link-icon-1.png">
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section> -->
<!--Project Two End-->


<!--Why Choose One Start-->
<section class="why-choose-one">
    <div class="container">
        <div class="why-choose-one__top">
            <div class="row">
                <div class="col-xl-8 col-lg-8 offset-2">
                    <div class="why-choose-one__right text-center">
                        <div class="section-title text-left">
                            <span class="section-title__tagline">Our Professionals</span>
                            <h2 class="section-title__title">Why Choose Us</h2>
                        </div>
                        <p class="why-choose-one__text">We are committed to delivering high quality services, waterproofing solutions, construction and repairs of building roofs. In order to maintain these systems, we deliver all-inclusive technical support from skilled waterproofing contractors in accordance with the significant structural waterproofing standards.</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="why-choose-one__bottom">
            <div class="row">
                <!--Why Choose One Single Start-->
                <div class="col-xl-4 col-lg-4">
                    <div class="why-choose-one__single">
                        <div class="icon">
                            <span class="icon-certificate"></span>
                        </div>
                        <div class="why-choose-one__content">
                            <h3 class="why-choose-one__title"><a href="about.html">Quality Assurance</a></h3>
                            <p class="why-choose-one__text-2">Quality is the foundation of our company. Our waterproofing products and brands are trusted and chosen by hundreds of people.</p>
                        </div>
                    </div>
                </div>
                <!--Why Choose One Single End-->
                <!--Why Choose One Single Start-->
                <div class="col-xl-4 col-lg-4">
                    <div class="why-choose-one__single">
                        <div class="icon">
                            <span class="icon-technician"></span>
                        </div>
                        <div class="why-choose-one__content">
                            <h3 class="why-choose-one__title"><a href="team.html">Customer Focus</a></h3>
                            <p class="why-choose-one__text-2">We have the capability of value-creation with strategic approaches to reach the best solutions for customers’ problems.</p>
                        </div>
                    </div>
                </div>
                <!--Why Choose One Single End-->
                <!--Why Choose One Single Start-->
                <div class="col-xl-4 col-lg-4">
                    <div class="why-choose-one__single">
                        <div class="icon">
                            <span class="icon-flag"></span>
                        </div>
                        <div class="why-choose-one__content">
                            <h3 class="why-choose-one__title"><a href="about.html">Innovation</a></h3>
                            <p class="why-choose-one__text-2">Our company has been built on stand-out product Innovations, and we all have at heart to keep up our innovative mind going.</p>
                        </div>
                    </div>
                </div>
                <!--Why Choose One Single End-->
            </div>
        </div>
    </div>
</section>
<!--Why Choose One End-->

<!--Site Footer Start-->
<footer class="site-footer">
    <div class="site-footer__shape-1 float-bob-x">
        <img src="assets/images/shapes/site-footer-shape-1.png">
    </div>
    <div class="site-footer__top">
        <div class="container">
            <div class="site-footer__inner">
                <div class="site-footer__contact-info">
                    <ul class="site-footer__contact-points list-unstyled">
                        <li>
                            <div class="icon">
                                <span class="icon-location"></span>
                            </div>
                            <div class="content">
                                <h4>Address :</h4>
                                <p>E-8/67, Basantkunj, Shahpura, Bhopal-462039</p>
                            </div>
                        </li>
                        <li>
                            <div class="icon">
                                <span class="icon-email"></span>
                            </div>
                            <div class="content">
                                <h4>Email us :</h4>
                                <a href="mailto:rkwaterproofingandcompanybpl@gmail.com">rkwaterproofingandcompanybpl@gmail.com</a>
                            </div>
                        </li>
                        <li>
                            <div class="icon">
                                <span class="icon-telephone"></span>
                            </div>
                            <div class="content">
                                <h4>Call us on :</h4>
                                <a href="tel:+91 9669967206">+91 9669967206</a>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="site-footer__middle">
        <div class="container">
            <div class="row">
                <div class="col-xl-4 col-lg-6 col-md-6 wow fadeInUp" data-wow-delay="100ms">
                    <div class=" footer-widget__column footer-widget__img-box">
                        <div class="footer-widget__img">
                            <img src="assets/images/resources/footer-widget-img-1.png">
                        </div>
                    </div>
                </div>
                <div class="col-xl-2 col-lg-6 col-md-6 wow fadeInUp" data-wow-delay="200ms">
                    <div class="footer-widget__column footer-widget__useful-links">
                        <div class="footer-widget__title-box">
                            <h3 class="footer-widget__title">Quick Links</h3>
                        </div>
                        <ul class="footer-widget__useful-links-list list-unstyled">
                            <li><a href="index.php">Home </a></li>
                            <li><a href="about.php">About Us</a></li>
                            <li><a href="services.php">Services</a></li>
                            <li><a href="work.php">Our Work</a></li>
                            <li><a href="gallery.php">Gallery</a></li>
                            <li><a href="contact.php">Contact Us</a></li>
                        </ul>
                    </div>
                    <div class="site-footer__social">
                       <a href="https://www.facebook.com/profile.php?id=100090751406407"><i class="fab fa-facebook-f"></i></a>
                        <a href="#"><i class="fab fa-google-plus-g"></i></a>
                        <a href="https://www.instagram.com/rkwaterproofingandcompany/"><i class="fab fa-instagram"></i></a> 
                        <a href="https://www.linkedin.com/in/rk-waterproofing-and-company-00262b272/"><i class="fab fa-linkedin-in"></i></a>                  
                    </div>
                </div>
                <div class="col-xl-3 col-lg-6 col-md-6 wow fadeInUp" data-wow-delay="300ms">
                    <div class="footer-widget__column footer-widget__services">
                        <div class="footer-widget__title-box">
                            <h3 class="footer-widget__title">Work we do</h3>
                        </div>
                        <ul class="footer-widget__useful-links-list list-unstyled">
                            <li><a href="work.php">Terrace Water Proofing</a></li>
                            <li><a href="work.php">Basement Water Proofing</a></li>
                            <li><a href="work.php">Terrace Garden System</a></li>
                            <li><a href="work.php">Sunken Water Proofing</a></li>
                            <li><a href="work.php">Water Tank Water Proofing</a></li>
                            <li><a href="work.php">Swimming Pool Water Proofing</a></li>
                            <li><a href="work.php">Injection Grouting</a></li>
                            <li><a href="work.php">Expansion Joint Work</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-6 col-md-6 wow fadeInUp" data-wow-delay="400ms">
                    <div class="footer-widget__column footer-widget__services">
                        <div class="footer-widget__title-box">
                            <h3 class="footer-widget__title">Work we do</h3>
                        </div>
                        <ul class="footer-widget__useful-links-list list-unstyled">
                            
                            <li><a href="work.php"> Waterproofing Work</a></li>
                            <li><a href="work.php">Painting Work</a></li>
                          	<li><a href="work.php">Heat Insulating Coating</a></li>
                            <li><a href="work.php">Protective Coating</a></li>
                            <li><a href="work.php">Construction Chemicals</a></li>
                            <li><a href="work.php">Capillary Waterproofing</a></li>
                            <li><a href="work.php">Interior & Exterior Wall Treatment</a></li>
                            <li><a href="work.php">Old & New Building Joint Works</a></li>
                        </ul>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
    <div class="site-footer__bottom">
        <div class="container">
            <div class="row">
                <div class="col-xl-12">
                    <div class="site-footer__bottom-inner">
                        <p class="site-footer__bottom-text">Copyright © 2024  <a href="#">R.K. Waterproofing and Company</a>. All right reserved | Designed & Developed by: <a href="https://ginfosoft.com/" target="_blank">G-INFOSOFT TECHNOLOGIES</a></p>
                        <!-- <div class="site-footer__bottom-text-two">
                            <a href="#!">Purchase Now</a>
                        </div> -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<!--Site Footer End-->


</div><!-- /.page-wrapper -->


<div class="mobile-nav__wrapper">
    <div class="mobile-nav__overlay mobile-nav__toggler"></div>
    <!-- /.mobile-nav__overlay -->
    <div class="mobile-nav__content">
        <span class="mobile-nav__close mobile-nav__toggler"><i class="fa fa-times"></i></span>

        <div class="logo-box">
            <a href="index.html" aria-label="logo image"><img src="assets/images/resources/logo-1.png" width="200"
                    /></a>
        </div>
        <!-- /.logo-box -->
        <div class="mobile-nav__container"></div>
        <!-- /.mobile-nav__container -->

        <ul class="mobile-nav__contact list-unstyled">
            <li>
                <i class="fa fa-envelope"></i>
                <a href="mailto:rkwaterproofingandcompanybpl@gmail.com">rkwaterproofingandcompanybpl@gmail.com</a>
            </li>
            <li>
                <i class="fa fa-phone-alt"></i>
                <a href="tel:666-888-0000">+91 9669967206</a>
            </li>
        </ul><!-- /.mobile-nav__contact -->
        <div class="mobile-nav__top">
            <div class="mobile-nav__social">
                <a href="#" class="fab fa-twitter"></a>
                <a href="#" class="fab fa-facebook-square"></a>
                <a href="#" class="fab fa-instagram"></a>
            </div><!-- /.mobile-nav__social -->
        </div><!-- /.mobile-nav__top -->



    </div>
    <!-- /.mobile-nav__content -->
</div>
<!-- /.mobile-nav__wrapper -->

    

<a href="#" data-target="html" class="scroll-to-target scroll-to-top"><i class="fa fa-angle-up"></i></a>


<script src="assets/vendors/jquery/jquery-3.6.0.min.js"></script>
<script src="assets/vendors/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/vendors/jarallax/jarallax.min.js"></script>
<script src="assets/vendors/jquery-ajaxchimp/jquery.ajaxchimp.min.js"></script>
<script src="assets/vendors/jquery-appear/jquery.appear.min.js"></script>
<script src="assets/vendors/jquery-circle-progress/jquery.circle-progress.min.js"></script>
<script src="assets/vendors/jquery-magnific-popup/jquery.magnific-popup.min.js"></script>
<script src="assets/vendors/jquery-validate/jquery.validate.min.js"></script>
<script src="assets/vendors/nouislider/nouislider.min.js"></script>
<script src="assets/vendors/odometer/odometer.min.js"></script>
<script src="assets/vendors/swiper/swiper.min.js"></script>
<script src="assets/vendors/tiny-slider/tiny-slider.min.js"></script>
<script src="assets/vendors/wnumb/wNumb.min.js"></script>
<script src="assets/vendors/wow/wow.js"></script>
<script src="assets/vendors/isotope/isotope.js"></script>
<script src="assets/vendors/countdown/countdown.min.js"></script>
<script src="assets/vendors/owl-carousel/owl.carousel.min.js"></script>
<script src="assets/vendors/bxslider/jquery.bxslider.min.js"></script>
<script src="assets/vendors/bootstrap-select/js/bootstrap-select.min.js"></script>
<script src="assets/vendors/vegas/vegas.min.js"></script>
<script src="assets/vendors/jquery-ui/jquery-ui.js"></script>
<script src="assets/vendors/timepicker/timePicker.js"></script>
<script src="assets/vendors/circleType/jquery.circleType.js"></script>
<script src="assets/vendors/circleType/jquery.lettering.min.js"></script>
<script src="assets/vendors/sidebar-content/jquery-sidebar-content.js"></script>


<script src="assets/vendors/tweenmax/TweenMax.min.js"></script>
<!-- Template js -->
<script src="assets/js/endreox.js"></script>

</body>
</html>